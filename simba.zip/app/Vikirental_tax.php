<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vikirental_tax extends Model
{
    protected $fillable=['tax_name','tax_rate'];
}
