<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vikicar_characteristics extends Model
{
    protected $fillable=['viki_cars_assigned','name','text'];
}
