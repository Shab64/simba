<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vikirental_priceType extends Model
{
    protected $fillable=['name','attributes','tax_id'];
}
