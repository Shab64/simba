<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AddtionalOptions extends Model
{
    protected $fillable=['boost_seat','child_seat','gold_cover','additional_seat','driver_for','silver_cover','basic_cover'];
}
