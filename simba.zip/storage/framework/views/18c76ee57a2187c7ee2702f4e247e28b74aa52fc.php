<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <!-- Container Fluid Reservation section content-->
                <div class="row">
                    <div class="col-lg-12">
                        <form action="<?php echo e(url('admin/add_driver')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">Add New Driver</h5>
                                </div>
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <div class="card-body">
                                    <div class="live-preview">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <label for="regNumber" class="form-label mt-3">Select Branch</label>
                                                <select name="branch" class="form-select" style="margin-bottom: 30px;">
                                                    <option>Sydney</option>
                                                    <option>Adelaide</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="regNumber" class="form-label">Name</label>
                                                <input type="text" value="<?php echo e(old('name')); ?>" class="form-control" name="name">


                                            </div>
                                            <div class="col-sm-6">
                                                <label for="regNumber" class="form-label">Email</label>
                                                <input type="email" value="<?php echo e(old('email')); ?>" class="form-control" name="email">
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="regNumber" class="form-label mt-3">Phone</label>
                                                <input type="text" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>">

                                            </div>


                                            <div class="col-sm-6">

                                                <label for="regNumber" class="form-label mt-3">Driving License No</label>
                                                <input type="text" class="form-control" value="<?php echo e(old('d_license_no')); ?>" name="d_license_no">

                                            </div>
                                        </div>
                                        <!--end row-->
                                    </div>
                                    <!-- Button -->
                                    <button type="submit" class="btn btn-primary mt-3">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\xampp\htdocs\laravel\simba\resources\views/admin/add-new-driver.blade.php ENDPATH**/ ?>