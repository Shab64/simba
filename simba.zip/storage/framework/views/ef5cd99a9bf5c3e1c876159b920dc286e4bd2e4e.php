<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <!-- Container Fluid Reservation section content-->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header border-bottom-dashed">

                                <div class="row g-4 align-items-center">
                                    <div class="col-sm">
                                        <div>
                                            <h5 class="card-title mb-0">Add User For Account</h5>
                                        </div>
                                    </div>
                                </div>
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <form action="<?php echo e(url('admin/add_user')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                            <div class="card-body">
                             <div class="row">
                                 <div class="col-md-12">
                                     <label for="regNumber" class="form-label">Select Branch</label>
                                     <select name="branch" id="" class="form-control form-select" style="margin-bottom: 30px;">
                                         <option>Adelaide</option>
                                         <option>Sydney</option>
                                     </select>
                                 </div>
                                 <div class="col-md-6">
                                     <div>
                                         <label for="regNumber" class="form-label">Name</label>
                                         <input type="text" class="form-control" id="regNumber" name="name">
                                     </div>
                                 </div>
                                 <div class="col-md-6">
                                     <div>
                                         <label for="regNumber" class="form-label">Email</label>
                                         <input type="email" name="email" class="form-control" id="regNumber">
                                     </div>
                                 </div>
                                 <div class="col-md-6 mt-4">
                                     <div>
                                         <label for="regNumber" class="form-label">Password</label>
                                         <input type="text" name="password" class="form-control" id="regNumber">
                                     </div>
                                 </div>
                                 <div class="col-md-6 mt-4">
                                     <div>
                                         <label for="regNumber" class="form-label">Select User Type</label>
                                         <select name="type" id="" class="form-control">
                                             <option>Branch Manager</option>
                                             <option>Employee</option>
                                         </select>
                                     </div>
                                 </div>

                             </div>
                                <button type="submit" class="btn btn-primary mt-5">Submit</button>
                            </div>
                            </form>
                        </div>

                    </div>
                    <!--end col-->
                </div>
                <!-- row end -->
            </div>
        </div>
    </div>


    <!-- End Page-content -->
<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\xampp\htdocs\laravel\simba\resources\views/admin/add-user.blade.php ENDPATH**/ ?>