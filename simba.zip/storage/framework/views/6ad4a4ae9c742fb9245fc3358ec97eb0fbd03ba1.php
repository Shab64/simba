<?php echo $__env->make('users.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <link rel="stylesheet" href="<?php echo e(url('assets/users')); ?>/css/vik.css">

<!--    <link rel="stylesheet" href="<?php echo e(url('assets/users')); ?>/css/frm-wiz/mStyle.css">-->
<!--    <link rel="stylesheet" href="<?php echo e(url('assets/users')); ?>/css/frm-wiz/js-steps.css">-->



    <style>

        .nav .nav-item::marker{
            color:transparent !important;
        }

        .nav .nav-item{
            flex: 1;
            text-align: center;
        }
        .nav-pills .nav-link{
            margin:auto;
            width: 100%;
            font-weight: bold;
            background: #f7f7f7;
        }
        .vrc-oconfirm-paym-block .vrc-gpay-licont-active{
            flex:1;

        }
        .vrc-oconfirm-paym-block .vrc-gpay-licont-active:before{
            display:none;
        }
        .nav-pills .nav-link.active, .nav-pills .show>.nav-link {
            color: #fff;
            background-color: #283891;
        }
        .vrc-showprc-left{
            order:0;
        }
        .vrc-showprc-container{
            align-items: center;
        }
        .vrcinfocarcontainer{
            border: 1px solid rgb(221, 221, 221);
            border-radius: 8px;
            align-items: center;
        }
        .vrcrentforlocs{
            border:none;
        }
        .vrccustomfields{
            display:block;
        }
        .vrc-oconfirm-summary-car-cell-descr .vrc-oconfirm-carname{
            color:black;
        }
        .vrc-oconfirm-summary-total-wrapper .vrc-oconfirm-summary-total-row, .vrc-oconfirm-summary-total-wrapper .vrc-oconfirm-summary-total-row .vrc-oconfirm-total-block{
            color:black;
        }

    /*wizard css*/
        .wizard>.steps .current a, .wizard>.steps .current a:hover, .wizard>.steps .current a:active {
            background: #2184be;
            color: #fff;
            cursor: default;
        }
        .wizard>.steps a, .wizard>.steps a:hover, .wizard>.steps a:active {
            display: block;
            width: auto;
            margin: 0 0.5em 0.5em;
            padding: 1em 1em;
            text-decoration: none;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
        }
        .wizard a, .tabcontrol a {
            outline: 0;
        }
        .wizard ul, .tabcontrol ul {
            list-style: none!important;
            padding: 0;
            margin: 0;
        }
        .wizard>.steps>ul>li, .wizard>.actions>ul>li {
            float: left;
        }
        .wizard>.steps>ul>li {
            width: 25%;
        }
        .wizard>.actions .disabled a, .wizard>.actions .disabled a:hover, .wizard>.actions .disabled a:active {
            background: #ccc;
            color: #aaa;
        }
        .wizard>.actions>ul>li {
            margin: 0 0.5em;
        }
        .clearfix:before, .clearfix:after {
            display: table;
            content: "";
            line-height: 0;
        }
        .wizard ul>li, .tabcontrol ul>li {
            display: block;
            padding: 0;
        }
        .wizard>.steps .disabled a, .wizard>.steps .disabled a:hover, .wizard>.steps .disabled a:active {
            background: #eee;
            color: #aaa;
            cursor: default;
        }
        .wizard>.content>.title, .tabcontrol>.content>.title {
            position: absolute;
            left: -999em;
        }
        .wizard>.steps .done a, .wizard>.steps .done a:hover, .wizard>.steps .done a:active {
            background: #9dc8e2;
            color: #fff;
        }
        .wizard>.actions a, .wizard>.actions a:hover, .wizard>.actions a:active {
            background: #2184be;
            color: #fff;
            display: block;
            padding: 0.5em 1em;
            text-decoration: none;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
            margin-top: 18px;
        }
        .current-info {
            opacity: 0;
        }

    </style>

    <section class="product-listing page-section-ptb">

        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body checkout-tab">
                            <form action="" method="post" class="vrc-showprc-form">
                            <div id="example-basic">
                                <h3>Dates</h3>
                                <section>
                                    <div class="row g-0 inner-service" >
                                        <div class="col-md-6 col-sm-6">
                                            <div class="feature-box-2 text-center">
                                                <div class="icon">
                                                    <h5>Pick Up</h5>
                                                </div>
                                                <div class="content">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <i class="glyph-icon flaticon-car"></i>
                                                            <p><?php echo e((!empty($search_results['p_location'])) ? $search_results['p_location'] : ""); ?></p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p>
                                                                <i class="fa fa-calendar"></i>
                                                                <?php echo e((!empty($search_results['p_date'])) ? $search_results['p_date'] : ""); ?>

                                                            </p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p>
                                                                <i class="fa fa-clock-o"></i>
                                                                <?php echo e((!empty($search_results['p_time'])) ? $search_results['p_time'] : ""); ?>

                                                            </p>
                                                        </div>






                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-sm-6">
                                            <div class="feature-box-2 no-br text-center">
                                                <div class="icon">
                                                    <h5>Drop Off</h5>

                                                </div>
                                                <div class="content">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <i class="glyph-icon flaticon-gas-station"></i>
                                                            <p>
                                                                <?php echo e((!empty($search_results['d_location'])) ? $search_results['d_location'] : ""); ?>

                                                            </p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p>
                                                                <i class="fa fa-calendar"></i>
                                                                <?php echo e((!empty($search_results['d_date'])) ? $search_results['d_date'] : ""); ?>

                                                            </p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p>
                                                                <i class="fa fa-clock-o"></i>
                                                                <?php echo e((!empty($search_results['d_time'])) ? $search_results['d_time'] : ""); ?>

                                                            </p>
                                                        </div>






                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </section>
                                <h3>Cars</h3>
                                <section>
                                    <div class="row g-0 inner-service" >
                                        <div class="row product-listing mt-5" style="margin:auto;">
                                            <div class="col-lg-12 col-md-8">
                                                <?php $__empty_1 = true; $__currentLoopData = $all_cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <div class="car-grid">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-12">
                                                            <div class="car-item gray-bg text-center">
                                                                <div class="car-image">
                                                                    <img class="img-fluid" src="<?php echo e(url('storage/app/public/carlist/'.$c['image'])); ?>" alt="">






                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-8 col-md-12">
                                                            <div class="car-details">
                                                                <div class="car-title">
                                                                    <a href="#"><?php echo e($c['name']); ?> or similar</a>

                                                                </div>
                                                                <h6>Starting From</h6>
                                                                <div class="price">
                                                                    <span class="new-price">$<?php echo e($c['daily_start_price']); ?></span>

                                                                    <input type="radio" name="shab_car" value="<?php echo e($c['id']); ?>" style="float: right" >
                                                                </div>











                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div>
                                </section>
                                <h3>Options</h3>
                                <section>

                                       <div id="show_vehicle_details"></div>


                                        <div class="vrc-showprc-options-wrap">
                                            <h4 class="vrc-showprc-title">Options</h4>
                                            <div class="vrc-showprc-options-inner">
                                                <div class="vrc-showprc-option-row">
                                                    <div class="vrc-showprc-option-cell-info">
                                                        <div class="vrc-showprc-option-name-descr">
                                                            <div class="vrc-showprc-option-name">
                                                                <span>BASIC COVER</span>
                                                            </div>
                                                            <div class="vrc-showprc-option-cell-descr">
                                                                <div class="vrcoptionaldescr">If you have an accident or damage the vehicle, your excess liability is $4,818.</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="vrc-showprc-option-cell-price">
                                                        <div class="vrc-showprc-option-cell-price-descr">
                                                            <span class="vrc_currency">$</span>
                                                            <span class="vrc_price"><?php echo e((!empty($additional_options[0]['basic_cover'])) ? $additional_options[0]['basic_cover'] : 0); ?></span>
                                                        </div>
                                                        <div class="vrc-showprc-option-cell-price-sel">
                                                            <input type="checkbox" name="basic_cover" value="yes">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="vrc-showprc-option-row">
                                                    <div class="vrc-showprc-option-cell-info">
                                                        <div class="vrc-showprc-option-name-descr">
                                                            <div class="vrc-showprc-option-name">
                                                                <span>Silver Cover</span>
                                                            </div>
                                                            <div class="vrc-showprc-option-cell-descr">
                                                                <div class="vrcoptionaldescr"><span style="color: #0000ff">This allows you to reduce the excess liability to $1800.&nbsp; Includes Roadside Assistance</span></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="vrc-showprc-option-cell-price">
                                                        <div class="vrc-showprc-option-cell-price-descr">
                                                            <span class="vrc_currency">$</span>
                                                            <span class="vrc_price"><?php echo e((!empty($additional_options[0]['silver_cover'])) ? $additional_options[0]['silver_cover'] : 0); ?></span>
                                                        </div>
                                                        <div class="vrc-showprc-option-cell-price-sel">
                                                            <input type="checkbox" name="silver_cover" value="yes">					</div>
                                                    </div>
                                                </div>
                                                <div class="vrc-showprc-option-row">
                                                    <div class="vrc-showprc-option-cell-info">
                                                        <div class="vrc-showprc-option-name-descr">
                                                            <div class="vrc-showprc-option-name">
                                                                <span>Gold Cover</span>
                                                            </div>
                                                            <div class="vrc-showprc-option-cell-descr">
                                                                <div class="vrcoptionaldescr"><span style="color: #0000ff">This allows you to reduce the excess liability to $0. </span><span style="color: #0000ff">Includes Roadside Assistance</span></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="vrc-showprc-option-cell-price">
                                                        <div class="vrc-showprc-option-cell-price-descr">
                                                            <span class="vrc_currency">$</span>
                                                            <span class="vrc_price"><?php echo e((!empty($additional_options[0]['gold_cover'])) ? $additional_options[0]['gold_cover'] : 0); ?></span>
                                                        </div>
                                                        <div class="vrc-showprc-option-cell-price-sel">
                                                            <input type="checkbox" name="gold_cover" value="yes">					</div>
                                                    </div>
                                                </div>
                                                <div class="vrc-showprc-option-row">
                                                    <div class="vrc-showprc-option-cell-info">
                                                        <div class="vrc-showprc-option-name-descr">
                                                            <div class="vrc-showprc-option-name">
                                                                <span>Drivers Under 25 and Over 75 Years</span>
                                                            </div>
                                                            <div class="vrc-showprc-option-cell-descr">
                                                                <div class="vrcoptionaldescr">You MUST select this option if you are under 25 or Over 75 years Old.

                                                                    Excess For Drivers under 25 and Over 75 is $5000.</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="vrc-showprc-option-cell-price">
                                                        <div class="vrc-showprc-option-cell-price-descr">
                                                            <span class="vrc_currency">$</span>
                                                            <span class="vrc_price"><?php echo e((!empty($additional_options[0]['driver_for'])) ? $additional_options[0]['driver_for'] : 0); ?></span>
                                                        </div>
                                                        <div class="vrc-showprc-option-cell-price-sel">
                                                            <input type="checkbox" name="driver_for" value="yes">					</div>
                                                    </div>
                                                </div>
                                                <div class="vrc-showprc-option-row">
                                                    <div class="vrc-showprc-option-cell-info">
                                                        <div class="vrc-showprc-option-name-descr">
                                                            <div class="vrc-showprc-option-name">
                                                                <span>Additional Driver</span>
                                                            </div>
                                                            <div class="vrc-showprc-option-cell-descr">
                                                                <div class="vrcoptionaldescr">Use this option if there is more then 1 Driver.</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="vrc-showprc-option-cell-price">
                                                        <div class="vrc-showprc-option-cell-price-descr">
                                                            <span class="vrc_currency">$</span>
                                                            <span class="vrc_price"><?php echo e((!empty($additional_options[0]['additional_driver'])) ? $additional_options[0]['additional_driver'] : 0); ?></span>
                                                        </div>
                                                        <div class="vrc-showprc-option-cell-price-sel">
                                                            <input type="number" min="0" step="any" name="additional_driver" value="0" size="5">					</div>
                                                    </div>
                                                </div>
                                                <div class="vrc-showprc-option-row">
                                                    <div class="vrc-showprc-option-cell-info">
                                                        <div class="vrc-showprc-option-name-descr">
                                                            <div class="vrc-showprc-option-name">
                                                                <span>Child Seat</span>
                                                            </div>
                                                            <div class="vrc-showprc-option-cell-descr">
                                                                <div class="vrcoptionaldescr">For Children between 0-4 Years</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="vrc-showprc-option-cell-price">
                                                        <div class="vrc-showprc-option-cell-price-descr">
                                                            <span class="vrc_currency">$</span>
                                                            <span class="vrc_price"><?php echo e((!empty($additional_options[0]['child_seat'])) ? $additional_options[0]['child_seat'] : 0); ?></span>
                                                        </div>
                                                        <div class="vrc-showprc-option-cell-price-sel">
                                                            <input type="number" min="0" step="any" name="child_seat" value="0" size="5">					</div>
                                                    </div>
                                                </div>
                                                <div class="vrc-showprc-option-row">
                                                    <div class="vrc-showprc-option-cell-info">
                                                        <div class="vrc-showprc-option-name-descr">
                                                            <div class="vrc-showprc-option-name">
                                                                <span>Booster Seat</span>
                                                            </div>
                                                            <div class="vrc-showprc-option-cell-descr">
                                                                <div class="vrcoptionaldescr">For Children between 4-8 Years</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="vrc-showprc-option-cell-price">
                                                        <div class="vrc-showprc-option-cell-price-descr">
                                                            <span class="vrc_currency">$</span>
                                                            <span class="vrc_price"><?php echo e((!empty($additional_options[0]['boost_seat'])) ? $additional_options[0]['boost_seat'] : 0); ?></span>
                                                        </div>
                                                        <div class="vrc-showprc-option-cell-price-sel">
                                                            <input type="number" min="0" step="any" name="boost_seat" value="0" size="5">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <input type="hidden" name="p_date" value="<?=$search_results['p_date']?>">
                                        <input type="hidden" name="r_date" value="<?=$search_results['d_date']?>">
                                        <input type="hidden" name="p_time" value="<?=$search_results['p_time']?>">
                                        <input type="hidden" name="r_time" value="<?=$search_results['d_time']?>">
                                        <input type="hidden" name="p_location" value="<?=$search_results['p_location']?>">
                                        <input type="hidden" name="d_location" value="<?=$search_results['d_location']?>">
                                        <!---->
                                        <!--                                        <div class="car_buttons_box">-->
                                        <!--                                            <input type="submit" name="goon" value="Book now" class="form-wizard-previous-btn btn booknow vrc-pref-color-btn">-->
                                        <!--                                            <div class="goback">-->
                                        <!--                                                <a href="#" class="form-wizard-next-btn btn vrc-pref-color-btn-secondary">Back</a>-->
                                        <!--                                            </div>-->
                                        <!--                                        </div>-->

                                </section>
                                <h3>Book</h3>
                                <section>
                                    <div class="vrcinfocarcontainer">
                                        <div class="vrcrentforlocs">
                                            <div class="vrcrentalfor">
                                                <h3 class="vrcrentalforone showCar_summary" >Rental Mitsubishi Mirage or similar for 27 Days</h3>
                                            </div>
                                            <div class="vrc-itinerary-confirmation">
                                                <div class="vrc-itinerary-pickup">
                                                    <h4>Pickup</h4>
                                                    <div class="vrc-itinerary-pickup-location">
                                                        <i class="fa fa-location-arrow vrc-pref-color-text"></i>					<div class="vrc-itinerary-pickup-locdet">
                                                            <span class="vrc-itinerary-pickup-locname"><?php echo e((!empty($search_results['p_location'])) ? $search_results['p_location'] : ""); ?></span>
                                                            <span class="vrc-itinerary-pickup-locaddr"></span>
                                                        </div>
                                                    </div>
                                                    <div class="vrc-itinerary-pickup-date">
                                                        <i class="fa fa-calendar vrc-pref-color-text"></i>					<span class="vrc-itinerary-pickup-date-day"><?php echo e((!empty($search_results['p_date'])) ? $search_results['p_date'] : ""); ?></span>
                                                        <span class="vrc-itinerary-pickup-date-time"><?php echo e((!empty($search_results['p_time'])) ? $search_results['p_time'] : ""); ?></span>
                                                    </div>
                                                </div>
                                                <div class="vrc-itinerary-dropoff">
                                                    <h4>Drop Off</h4>
                                                    <div class="vrc-itinerary-dropoff-location">
                                                        <i class="fa fa-location-arrow vrc-pref-color-text"></i>					<div class="vrc-itinerary-dropfff-locdet">
                                                            <span class="vrc-itinerary-dropoff-locname"><?php echo e((!empty($search_results['d_location'])) ? $search_results['d_location'] : ""); ?></span>
                                                            <span class="vrc-itinerary-dropoff-locaddr"></span>
                                                        </div>
                                                    </div>
                                                    <div class="vrc-itinerary-dropoff-date">
                                                        <i class="fa fa-calendar vrc-pref-color-text"></i>					<span class="vrc-itinerary-dropoff-date-day"><?php echo e((!empty($search_results['d_date'])) ? $search_results['d_date'] : ""); ?></span>
                                                        <span class="vrc-itinerary-dropoff-date-time"><?php echo e((!empty($search_results['d_time'])) ? $search_results['d_time'] : ""); ?></span>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>

                                        <div class="vrc-summary-car-img">
                                            <img src="https://www.simbacarhire.com.au/wp-content/plugins/vikrentcar/admin/resources/mirage-320x181.png" class="showCarimg_summary">
                                        </div>
                                    </div>

                                    <div id="show_additional_info"></div>


                                    <div class="vrccustomfields">
                                        <div class="vrcdivcustomfield vrccustomfldinfo">
                                            <div class="vrcseparatorcf">Driver Information</div>
                                        </div>
                                        <div class="vrcdivcustomfield">
                                            <div class="vrc-customfield-label">
                                                <span class="vrcrequired"><sup>*</sup></span> 					<label id="vrcf2" for="vrcf-inp2">Name</label>				</div>
                                            <div class="vrc-customfield-input">
                                                <input type="text" name="vrcf2" id="vrcf-inp2" value="" size="40" class="vrcinput wizard-required">
                                            </div>
                                        </div>
                                        <div class="vrcdivcustomfield">
                                            <div class="vrc-customfield-label">
                                                <span class="vrcrequired"><sup>*</sup></span> 					<label id="vrcf3" for="vrcf-inp3">Last Name</label>				</div>
                                            <div class="vrc-customfield-input">
                                                <input type="text" name="vrcf3" id="vrcf-inp3" value="" size="40" class="vrcinput">
                                            </div>
                                        </div>
                                        <div class="vrcdivcustomfield">
                                            <div class="vrc-customfield-label">
                                                <span class="vrcrequired"><sup>*</sup></span> 					<label id="vrcf4" for="vrcf-inp4">e-Mail</label>				</div>
                                            <div class="vrc-customfield-input">
                                                <input type="text" name="vrcf4" id="vrcf-inp4" value="" size="40" class="vrcinput">
                                            </div>
                                        </div>
                                        <div class="vrcdivcustomfield">
                                            <div class="vrc-customfield-label">
                                                <label id="vrcf5" for="vrcf-inp5">Phone</label>				</div>
                                            <div class="vrc-customfield-input">
                                                <input type="text" name="vrcf5" id="vrcf-inp5" value="" size="40" class="vrcinput">
                                            </div>
                                        </div>
                                        <div class="vrcdivcustomfield">
                                            <div class="vrc-customfield-label">
                                                <label id="vrcf6" for="vrcf-inp6">Address</label>				</div>
                                            <div class="vrc-customfield-input">
                                                <input type="text" name="vrcf6" id="vrcf-inp6" value="" size="40" class="vrcinput">
                                            </div>
                                        </div>
                                        <div class="vrcdivcustomfield">
                                            <div class="vrc-customfield-label">
                                                <label id="vrcf7" for="vrcf-inp7">Zip Code</label>				</div>
                                            <div class="vrc-customfield-input">
                                                <input type="text" name="vrcf7" id="vrcf-inp7" value="" size="40" class="vrcinput">
                                            </div>
                                        </div>
                                        <div class="vrcdivcustomfield">
                                            <div class="vrc-customfield-label">
                                                <label id="vrcf8" for="vrcf-inp8">City</label>				</div>
                                            <div class="vrc-customfield-input">
                                                <input type="text" name="vrcf8" id="vrcf-inp8" value="" size="40" class="vrcinput">
                                            </div>
                                        </div>
                                        <div class="vrcdivcustomfield">
                                            <div class="vrc-customfield-label">
                                                <span class="vrcrequired"><sup>*</sup></span> <label id="vrcf9" for="vrcf-inp9">Country</label>				</div>
                                            <div class="vrc-customfield-input">
                                                <select name="vrcf9" class="vrcf-countryinp"><option value=""></option>
                                                    <option value="AFG::Afghanistan">Afghanistan</option>
                                                    <option value="ALB::Albania">Albania</option>
                                                    <option value="DZA::Algeria">Algeria</option>
                                                    <option value="ASM::American Samoa">American Samoa</option>
                                                    <option value="AND::Andorra">Andorra</option>
                                                    <option value="AGO::Angola">Angola</option>
                                                    <option value="AIA::Anguilla">Anguilla</option>
                                                    <option value="ATA::Antarctica">Antarctica</option>
                                                    <option value="ATG::Antigua and Barbuda">Antigua and Barbuda</option>
                                                    <option value="ARG::Argentina">Argentina</option>
                                                    <option value="ARM::Armenia">Armenia</option>
                                                    <option value="ABW::Aruba">Aruba</option>
                                                    <option value="AUS::Australia">Australia</option>
                                                    <option value="AUT::Austria">Austria</option>
                                                    <option value="AZE::Azerbaijan">Azerbaijan</option>
                                                    <option value="BHS::Bahamas">Bahamas</option>
                                                    <option value="BHR::Bahrain">Bahrain</option>
                                                    <option value="BGD::Bangladesh">Bangladesh</option>
                                                    <option value="BRB::Barbados">Barbados</option>
                                                    <option value="BLR::Belarus">Belarus</option>
                                                    <option value="BEL::Belgium">Belgium</option>
                                                    <option value="BLZ::Belize">Belize</option>
                                                    <option value="BEN::Benin">Benin</option>
                                                    <option value="BMU::Bermuda">Bermuda</option>
                                                    <option value="BTN::Bhutan">Bhutan</option>
                                                    <option value="BOL::Bolivia">Bolivia</option>
                                                    <option value="BIH::Bosnia and Herzegowina">Bosnia and Herzegowina</option>
                                                    <option value="BWA::Botswana">Botswana</option>
                                                    <option value="BVT::Bouvet Island">Bouvet Island</option>
                                                    <option value="BRA::Brazil">Brazil</option>
                                                    <option value="IOT::British Indian Ocean Territory">British Indian Ocean Territory</option>
                                                    <option value="BRN::Brunei Darussalam">Brunei Darussalam</option>
                                                    <option value="BGR::Bulgaria">Bulgaria</option>
                                                    <option value="BFA::Burkina Faso">Burkina Faso</option>
                                                    <option value="BDI::Burundi">Burundi</option>
                                                    <option value="KHM::Cambodia">Cambodia</option>
                                                    <option value="CMR::Cameroon">Cameroon</option>
                                                    <option value="CAN::Canada">Canada</option>
                                                    <option value="XCA::Canary Islands">Canary Islands</option>
                                                    <option value="CPV::Cape Verde">Cape Verde</option>
                                                    <option value="CYM::Cayman Islands">Cayman Islands</option>
                                                    <option value="CAF::Central African Republic">Central African Republic</option>
                                                    <option value="TCD::Chad">Chad</option>
                                                    <option value="CHL::Chile">Chile</option>
                                                    <option value="CHN::China">China</option>
                                                    <option value="CXR::Christmas Island">Christmas Island</option>
                                                    <option value="CCK::Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                                                    <option value="COL::Colombia">Colombia</option>
                                                    <option value="COM::Comoros">Comoros</option>
                                                    <option value="COG::Congo">Congo</option>
                                                    <option value="COK::Cook Islands">Cook Islands</option>
                                                    <option value="CRI::Costa Rica">Costa Rica</option>
                                                    <option value="CIV::Cote D'Ivoire">Cote D'Ivoire</option>
                                                    <option value="HRV::Croatia">Croatia</option>
                                                    <option value="CUB::Cuba">Cuba</option>
                                                    <option value="CYP::Cyprus">Cyprus</option>
                                                    <option value="CZE::Czech Republic">Czech Republic</option>
                                                    <option value="DNK::Denmark">Denmark</option>
                                                    <option value="DJI::Djibouti">Djibouti</option>
                                                    <option value="DMA::Dominica">Dominica</option>
                                                    <option value="DOM::Dominican Republic">Dominican Republic</option>
                                                    <option value="TMP::East Timor">East Timor</option>
                                                    <option value="XET::East Timor">East Timor</option>
                                                    <option value="ECU::Ecuador">Ecuador</option>
                                                    <option value="EGY::Egypt">Egypt</option>
                                                    <option value="SLV::El Salvador">El Salvador</option>
                                                    <option value="GNQ::Equatorial Guinea">Equatorial Guinea</option>
                                                    <option value="ERI::Eritrea">Eritrea</option>
                                                    <option value="EST::Estonia">Estonia</option>
                                                    <option value="ETH::Ethiopia">Ethiopia</option>
                                                    <option value="FLK::Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                                                    <option value="FRO::Faroe Islands">Faroe Islands</option>
                                                    <option value="FJI::Fiji">Fiji</option>
                                                    <option value="FIN::Finland">Finland</option>
                                                    <option value="FRA::France">France</option>
                                                    <option value="GUF::French Guiana">French Guiana</option>
                                                    <option value="PYF::French Polynesia">French Polynesia</option>
                                                    <option value="ATF::French Southern Territories">French Southern Territories</option>
                                                    <option value="GAB::Gabon">Gabon</option>
                                                    <option value="GMB::Gambia">Gambia</option>
                                                    <option value="GEO::Georgia">Georgia</option>
                                                    <option value="DEU::Germany">Germany</option>
                                                    <option value="GHA::Ghana">Ghana</option>
                                                    <option value="GIB::Gibraltar">Gibraltar</option>
                                                    <option value="GRC::Greece">Greece</option>
                                                    <option value="GRL::Greenland">Greenland</option>
                                                    <option value="GRD::Grenada">Grenada</option>
                                                    <option value="GLP::Guadeloupe">Guadeloupe</option>
                                                    <option value="GUM::Guam">Guam</option>
                                                    <option value="GTM::Guatemala">Guatemala</option>
                                                    <option value="GIN::Guinea">Guinea</option>
                                                    <option value="GNB::Guinea-bissau">Guinea-bissau</option>
                                                    <option value="GUY::Guyana">Guyana</option>
                                                    <option value="HTI::Haiti">Haiti</option>
                                                    <option value="HMD::Heard and Mc Donald Islands">Heard and Mc Donald Islands</option>
                                                    <option value="HND::Honduras">Honduras</option>
                                                    <option value="HKG::Hong Kong">Hong Kong</option>
                                                    <option value="HUN::Hungary">Hungary</option>
                                                    <option value="ISL::Iceland">Iceland</option>
                                                    <option value="IND::India">India</option>
                                                    <option value="IDN::Indonesia">Indonesia</option>
                                                    <option value="IRN::Iran (Islamic Republic of)">Iran (Islamic Republic of)</option>
                                                    <option value="IRQ::Iraq">Iraq</option>
                                                    <option value="IRL::Ireland">Ireland</option>
                                                    <option value="ISR::Israel">Israel</option>
                                                    <option value="ITA::Italy">Italy</option>
                                                    <option value="JAM::Jamaica">Jamaica</option>
                                                    <option value="JPN::Japan">Japan</option>
                                                    <option value="XJE::Jersey">Jersey</option>
                                                    <option value="JOR::Jordan">Jordan</option>
                                                    <option value="KAZ::Kazakhstan">Kazakhstan</option>
                                                    <option value="KEN::Kenya">Kenya</option>
                                                    <option value="KIR::Kiribati">Kiribati</option>
                                                    <option value="PRK::Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                                                    <option value="KOR::Korea, Republic of">Korea, Republic of</option>
                                                    <option value="KWT::Kuwait">Kuwait</option>
                                                    <option value="KGZ::Kyrgyzstan">Kyrgyzstan</option>
                                                    <option value="LAO::Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                                                    <option value="LVA::Latvia">Latvia</option>
                                                    <option value="LBN::Lebanon">Lebanon</option>
                                                    <option value="LSO::Lesotho">Lesotho</option>
                                                    <option value="LBR::Liberia">Liberia</option>
                                                    <option value="LBY::Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                                                    <option value="LIE::Liechtenstein">Liechtenstein</option>
                                                    <option value="LTU::Lithuania">Lithuania</option>
                                                    <option value="LUX::Luxembourg">Luxembourg</option>
                                                    <option value="MAC::Macau">Macau</option>
                                                    <option value="MKD::Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option>
                                                    <option value="MDG::Madagascar">Madagascar</option>
                                                    <option value="MWI::Malawi">Malawi</option>
                                                    <option value="MYS::Malaysia">Malaysia</option>
                                                    <option value="MDV::Maldives">Maldives</option>
                                                    <option value="MLI::Mali">Mali</option>
                                                    <option value="MLT::Malta">Malta</option>
                                                    <option value="MHL::Marshall Islands">Marshall Islands</option>
                                                    <option value="MTQ::Martinique">Martinique</option>
                                                    <option value="MRT::Mauritania">Mauritania</option>
                                                    <option value="MUS::Mauritius">Mauritius</option>
                                                    <option value="MYT::Mayotte">Mayotte</option>
                                                    <option value="MEX::Mexico">Mexico</option>
                                                    <option value="FSM::Micronesia, Federated States of">Micronesia, Federated States of</option>
                                                    <option value="MDA::Moldova, Republic of">Moldova, Republic of</option>
                                                    <option value="MCO::Monaco">Monaco</option>
                                                    <option value="MNG::Mongolia">Mongolia</option>
                                                    <option value="MSR::Montserrat">Montserrat</option>
                                                    <option value="MAR::Morocco">Morocco</option>
                                                    <option value="MOZ::Mozambique">Mozambique</option>
                                                    <option value="MMR::Myanmar">Myanmar</option>
                                                    <option value="NAM::Namibia">Namibia</option>
                                                    <option value="NRU::Nauru">Nauru</option>
                                                    <option value="NPL::Nepal">Nepal</option>
                                                    <option value="NLD::Netherlands">Netherlands</option>
                                                    <option value="ANT::Netherlands Antilles">Netherlands Antilles</option>
                                                    <option value="NCL::New Caledonia">New Caledonia</option>
                                                    <option value="NZL::New Zealand">New Zealand</option>
                                                    <option value="NIC::Nicaragua">Nicaragua</option>
                                                    <option value="NER::Niger">Niger</option>
                                                    <option value="NGA::Nigeria">Nigeria</option>
                                                    <option value="NIU::Niue">Niue</option>
                                                    <option value="NFK::Norfolk Island">Norfolk Island</option>
                                                    <option value="MNP::Northern Mariana Islands">Northern Mariana Islands</option>
                                                    <option value="NOR::Norway">Norway</option>
                                                    <option value="OMN::Oman">Oman</option>
                                                    <option value="PAK::Pakistan">Pakistan</option>
                                                    <option value="PLW::Palau">Palau</option>
                                                    <option value="PAN::Panama">Panama</option>
                                                    <option value="PNG::Papua New Guinea">Papua New Guinea</option>
                                                    <option value="PRY::Paraguay">Paraguay</option>
                                                    <option value="PER::Peru">Peru</option>
                                                    <option value="PHL::Philippines">Philippines</option>
                                                    <option value="PCN::Pitcairn">Pitcairn</option>
                                                    <option value="POL::Poland">Poland</option>
                                                    <option value="PRT::Portugal">Portugal</option>
                                                    <option value="PRI::Puerto Rico">Puerto Rico</option>
                                                    <option value="QAT::Qatar">Qatar</option>
                                                    <option value="REU::Reunion">Reunion</option>
                                                    <option value="ROU::Romania">Romania</option>
                                                    <option value="RUS::Russian Federation">Russian Federation</option>
                                                    <option value="RWA::Rwanda">Rwanda</option>
                                                    <option value="KNA::Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                                    <option value="LCA::Saint Lucia">Saint Lucia</option>
                                                    <option value="VCT::Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                                                    <option value="WSM::Samoa">Samoa</option>
                                                    <option value="SMR::San Marino">San Marino</option>
                                                    <option value="STP::Sao Tome and Principe">Sao Tome and Principe</option>
                                                    <option value="SAU::Saudi Arabia">Saudi Arabia</option>
                                                    <option value="SEN::Senegal">Senegal</option>
                                                    <option value="SRB::Serbia">Serbia</option>
                                                    <option value="SYC::Seychelles">Seychelles</option>
                                                    <option value="SLE::Sierra Leone">Sierra Leone</option>
                                                    <option value="SGP::Singapore">Singapore</option>
                                                    <option value="MAF::Sint Maarten (French Antilles)">Sint Maarten (French Antilles)</option>
                                                    <option value="SXM::Sint Maarten (Netherlands Antilles)">Sint Maarten (Netherlands Antilles)</option>
                                                    <option value="SVK::Slovakia (Slovak Republic)">Slovakia (Slovak Republic)</option>
                                                    <option value="SVN::Slovenia">Slovenia</option>
                                                    <option value="SLB::Solomon Islands">Solomon Islands</option>
                                                    <option value="SOM::Somalia">Somalia</option>
                                                    <option value="ZAF::South Africa">South Africa</option>
                                                    <option value="SGS::South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
                                                    <option value="ESP::Spain">Spain</option>
                                                    <option value="LKA::Sri Lanka">Sri Lanka</option>
                                                    <option value="XSB::St. Barthelemy">St. Barthelemy</option>
                                                    <option value="XSE::St. Eustatius">St. Eustatius</option>
                                                    <option value="SHN::St. Helena">St. Helena</option>
                                                    <option value="SPM::St. Pierre and Miquelon">St. Pierre and Miquelon</option>
                                                    <option value="SDN::Sudan">Sudan</option>
                                                    <option value="SUR::Suriname">Suriname</option>
                                                    <option value="SJM::Svalbard and Jan Mayen Islands">Svalbard and Jan Mayen Islands</option>
                                                    <option value="SWZ::Swaziland">Swaziland</option>
                                                    <option value="SWE::Sweden">Sweden</option>
                                                    <option value="CHE::Switzerland">Switzerland</option>
                                                    <option value="SYR::Syrian Arab Republic">Syrian Arab Republic</option>
                                                    <option value="TWN::Taiwan">Taiwan</option>
                                                    <option value="TJK::Tajikistan">Tajikistan</option>
                                                    <option value="TZA::Tanzania, United Republic of">Tanzania, United Republic of</option>
                                                    <option value="THA::Thailand">Thailand</option>
                                                    <option value="DRC::The Democratic Republic of Congo">The Democratic Republic of Congo</option>
                                                    <option value="TGO::Togo">Togo</option>
                                                    <option value="TKL::Tokelau">Tokelau</option>
                                                    <option value="TON::Tonga">Tonga</option>
                                                    <option value="TTO::Trinidad and Tobago">Trinidad and Tobago</option>
                                                    <option value="TUN::Tunisia">Tunisia</option>
                                                    <option value="TUR::Turkey">Turkey</option>
                                                    <option value="TKM::Turkmenistan">Turkmenistan</option>
                                                    <option value="TCA::Turks and Caicos Islands">Turks and Caicos Islands</option>
                                                    <option value="TUV::Tuvalu">Tuvalu</option>
                                                    <option value="UGA::Uganda">Uganda</option>
                                                    <option value="UKR::Ukraine">Ukraine</option>
                                                    <option value="ARE::United Arab Emirates">United Arab Emirates</option>
                                                    <option value="GBR::United Kingdom">United Kingdom</option>
                                                    <option value="USA::United States">United States</option>
                                                    <option value="UMI::United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                                                    <option value="URY::Uruguay">Uruguay</option>
                                                    <option value="UZB::Uzbekistan">Uzbekistan</option>
                                                    <option value="VUT::Vanuatu">Vanuatu</option>
                                                    <option value="VAT::Vatican City State (Holy See)">Vatican City State (Holy See)</option>
                                                    <option value="VEN::Venezuela">Venezuela</option>
                                                    <option value="VNM::Viet Nam">Viet Nam</option>
                                                    <option value="VGB::Virgin Islands (British)">Virgin Islands (British)</option>
                                                    <option value="VIR::Virgin Islands (U.S.)">Virgin Islands (U.S.)</option>
                                                    <option value="WLF::Wallis and Futuna Islands">Wallis and Futuna Islands</option>
                                                    <option value="ESH::Western Sahara">Western Sahara</option>
                                                    <option value="YEM::Yemen">Yemen</option>
                                                    <option value="ZMB::Zambia">Zambia</option>
                                                    <option value="ZWE::Zimbabwe">Zimbabwe</option>
                                                </select>				</div>
                                        </div>
                                        <div class="vrcdivcustomfield">
                                            <div class="vrc-customfield-label">
                                                <span class="vrcrequired"><sup>*</sup></span> <label id="vrcf10" for="vrcf-inp10">Date of Birth</label>				</div>
                                            <div class="vrc-customfield-input vrc-customfield-input-date">
                                                <input type="text" name="vrcf10" id="vrcf-inp10" value="" size="40" class="vrcinput hasDatepicker">
                                            </div>
                                        </div>

                                        <div class="vrcdivcustomfield">
                                            <div class="vrc-customfield-label">
                                                <label id="vrcf11" for="vrcf-inp11">Flight Number</label>				</div>
                                            <div class="vrc-customfield-input">
                                                <input type="text" name="vrcf11" id="vrcf-inp11" value="" size="40" class="vrcinput">
                                            </div>
                                        </div>
                                        <div class="vrcdivcustomfield">
                                            <div class="vrc-customfield-label">
                                                <label id="vrcf12" for="vrcf-inp12">Notes</label>				</div>
                                            <div class="vrc-customfield-input">
                                                <textarea name="vrcf12" id="vrcf-inp12" rows="5" cols="30" class="vrctextarea"></textarea>
                                            </div>
                                        </div>
                                        <div class="vrcdivcustomfield vrc-oconfirm-cfield-entry-checkbox">
                                            <div class="vrc-customfield-label">
                                                <span class="vrcrequired"><sup>*</sup></span> <a href="https://www.simbacarhire.com.au/wp-content/uploads/2021/09/Simba-Car-Rental-Agreement.pdf" id="vrcf13" rel="{handler: 'iframe', size: {x: 750, y: 600}}" target="_blank" class="vrcmodal">I agree to the terms and conditions</a>				</div>
                                            <div class="vrc-customfield-input">
                                                <input type="checkbox" name="vrcf13" id="vrcf-inp13" value="Yes">
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="days" value="27">
                                    <input type="hidden" name="pickup" value="1650619800">
                                    <input type="hidden" name="release" value="1652952600">
                                    <input type="hidden" name="car" value="9">
                                    <input type="hidden" name="prtar" value="87">
                                    <input type="hidden" name="priceid" value="1">
                                    <input type="hidden" name="optionals" value="8:1;9:1;">
                                    <input type="hidden" name="totdue" value="2983.9525">
                                    <input type="hidden" name="place" value="2">
                                    <input type="hidden" name="returnplace" value="2">
                                    <input type="hidden" name="viktoken" value="1064625688f97590a1.57610782">
                                    <input type="hidden" id="vikwp_nonce" name="vikwp_nonce" value="25dd4da35b"><input type="hidden" name="_wp_http_referer" value="/">		<input type="hidden" name="task" value="saveorder">
                                    <div class="vrc-oconfirm-paym-block">
                                        <h4 class="vrc-medium-header">Payment Method</h4>
                                        <ul class="vrc-noliststyletype">
                                            <li class="vrc-gpay-licont vrc-gpay-licont-active">
                                                <input type="radio" name="gpayid" value="4" id="gpay4" checked="checked" >
                                                <label for="gpay4">
                                                    <span class="vrc-paymeth-info">Total Payment (+<span class="">1.50</span> <span class="">%</span>)</span>
                                                </label>
                                                <span class="vrc-payment-image">
                                    <label for="gpay4">
                                        <img src="https://www.simbacarhire.com.au/wp-content/uploads/2021/10/Simba_Final_webPNG.png" alt="Total Payment">
                                    </label>
				                    </span>
                                            </li>
                                        </ul>
                                    </div>
                                </section>
                            </div>
                            </form>
                        </div>
                        <!-- end card body -->
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
        </div>
    </section>
<?php
$earlier = new DateTime($search_results['p_date']);
$later = new DateTime($search_results['d_date']);
$total_days = $later->diff($earlier)->format("%a");
?>

    <script>

        function showDriverName() {
            let catchSelectId = document.getElementById('driver');
            let driver = document.getElementById('driverBlock');
            if (catchSelectId.options[catchSelectId.selectedIndex].value == "with") {
                driver.style.display = 'inline-block';
            } else {
                driver.style.display = 'none';
            }
        }

        function showHideTab() {
            let idTab1 = document.getElementById('paymentmethodCollapse');
            let idTab2 = document.getElementById('paymentMethod03');
            idTab1.style.display = 'block';
            idTab2.style.display = 'none';
        }

        function showHideTab02() {
            let idTab1 = document.getElementById('paymentmethodCollapse');
            let idTab2 = document.getElementById('paymentMethod03');
            idTab2.style.display = 'block';
            idTab1.style.display = 'none';
        }



        $(function(){
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            



            $("#example-basic").steps({
                headerTag: "h3",
                bodyTag: "section",
                transitionEffect: "slideLeft",
                transitionEffectSpeed: 200,
                autoFocus: true,
                onStepChanging: function (event, currentIndex, newIndex) {
                    let options={};
                    let otherOptions={};
                    if ( newIndex === 2 ) {
                        let vehicle_id = $("[name='shab_car']:checked").val();
                        let _token  = '<?php echo e(csrf_token()); ?>';
                        $.post("<?php echo e(url('/admin/onlineReservation/getAjaxData/vehicle')); ?>",{_token,vehicle_id},function (e){
                            $("#show_vehicle_details").html(e)
                        })
                    }
                    if (newIndex === 3){
                        $("input[type='checkbox']:checked").each(function (key,value){
                            options[key] =value.name;
                        })
                        $("input[type='number']").each(function (key,value){
                            otherOptions[value.name] =value.value;
                        })

                        let vehicle_id = $("[name='shab_car']:checked").val();
                        let totalDays = '<?php echo e($total_days); ?>';
                        let _token  = '<?php echo e(csrf_token()); ?>';
                        $.post("<?php echo e(url('/admin/onlineReservation/getAjaxData/additional_information')); ?>",{_token,vehicle_id,options,otherOptions,totalDays},function (e){
                            let carName = $(".vrhword").html();
                            let carSrc = $(".car_img_box img").attr('src');
                            $(".showCar_summary").html(carName)
                            $(".showCarimg_summary").attr('src',carSrc)
                            $("#show_additional_info").html(e)
                        })

                    }
                    return true;
                },
                labels: {
                    finish: "Confirm",
                    next: "Next",
                    previous: "Previous"
                }
            });
        });

    </script>


<?php echo $__env->make('users.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\xampp\htdocs\laravel\simba\resources\views/users/search-form-wizard3.blade.php ENDPATH**/ ?>