<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="<?php echo e(url('assets')); ?>/css/frm-wiz/mStyle.css">
<link rel="stylesheet" href="<?php echo e(url('assets')); ?>/css/frm-wiz/js-steps.css">
<link rel="stylesheet" href="<?php echo e(url('assets')); ?>/css/frm-wiz/dropify.css">
<link rel="stylesheet" href="<?php echo e(url('assets')); ?>/css/frm-wiz/nice-select.css">

<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets')); ?>/css/frm-wiz/daterangepicker.css" />
<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets')); ?>/css/frm-wiz/icon.css" />


<style>
    .hide{
        display: none;
    }
    .card-cars {
        /*box-shadow: rgba(67, 71, 85, 0.27) 0px 0px 0.25em, rgba(90, 125, 188, 0.05) 0px 0.25em 1em;*/
        cursor: pointer;
        transition: .8s;
        transition: transform .8s;
        background-color: aliceblue;
        margin-top: 55px;
        text-align: center;
    }

    .card-cars:hover {
        /* transform: scale(1.03); */
        transform: translateY(-5px);
        transition: .8s;


    }

    .card-cars:hover .car {
        box-shadow: 0px 0px 25px #e7e7e7;
    }



    .license-card {
        height: 70vh;
        overflow-y: scroll;
        box-shadow: rgba(67, 71, 85, 0.27) 0px 0px 0.25em, rgba(90, 125, 188, 0.05) 0px 0.25em 1em;

    }

    .img-figure-tag {
        /*border-radius: 25px;*/
        /*box-shadow: rgba(67, 71, 85, 0.27) 0px 0px 0.25em, rgba(90, 125, 188, 0.05) 0px 0.25em 1em;*/

    }
    .ribbon-content label{
        color:black;
    }
    .ribbon-box .card-body{
        margin-top: 12px;
    }
    .img-hover {
        transition: transform .8s;
    }

    .img-hover:hover {
        transform: scale(1.06);
    }

    .header-aggrement-main-div {
        align-items: center;
    }

    .agrement-header {
        text-align: end;

    }

    .car {
        width: 100%;
        margin: 0px auto;
        border-radius: 19px;
        background: aliceblue;
        position: relative;
        bottom: 30px;
        text-align: center;
        box-shadow: 0px 0px 15px #e7e7e7;
    }

    .car img {
        text-align: center;
        height: 160px;
    }

    .card-cars .card-title {
        font-size: 23px !important;
        text-align: center;
        font-weight: 700 !important;
    }

    .card-cars .card-body {
        padding-left: 0;
        padding-right: 0;
        padding-bottom: 0;
    }

    .card-cars button {
        width: 100%;
        border-radius: 0;
    }

    @media (max-width:767px) {
        .car {
            width: 100%;
            margin: 0px auto;
            border-radius: 19px;
            background: aliceblue;
            position: relative;
            bottom: 30px;
            text-align: center;
            box-shadow: 0px 0px 15px #e7e7e7;
        }
        .car img {
            text-align: center;
            height: auto;
        }
    }

    .dropzone.dz-clickable{
        position: relative;
        overflow: hidden;
    }

    .dropzone.dz-clickable input{
        opacity: 0;
        height: 100%;
        position: absolute;
        z-index: 99;
        left: 0;
    }

    h4{
        color: black!important;
    }

   .card .card-body .d-flex h4{
        display: block!important;
    }
    .card .card-body .d-flex p{
        color:black;
    }



    .wrapper .option{
        background: #5ea3cb;
        height: 100%;
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 10px;
        border-radius: 5px;
        cursor: pointer;
        padding: 0 10px;
        border: 2px solid #5ea3cb;
        transition: all 0.3s ease;
    }
    .wrapper .option .dot{
        height: 20px;
        width: 20px;
        background: #d9d9d9;
        border-radius: 50%;
        position: relative;
    }
    .wrapper .option .dot::before{
        position: absolute;
        content: "";
        top: 4px;
        left: 4px;
        width: 12px;
        height: 12px;
        background: #0069d9;
        border-radius: 50%;
        opacity: 0;
        transform: scale(1.5);
        transition: all 0.3s ease;
    }
    input[type="radio"]{
        /*visibility: hidden;*/
    }
    #option-1:checked:checked ~ .option-1,
    #option-2:checked:checked ~ .option-2{
        border-color: #0069d9;
        background: #0069d9;
    }
    #option-1:checked:checked ~ .option-1 .dot,
    #option-2:checked:checked ~ .option-2 .dot{
        background: #fff;
    }
    #option-1:checked:checked ~ .option-1 .dot::before,
    #option-2:checked:checked ~ .option-2 .dot::before{
        opacity: 1;
        transform: scale(1);
    }
    .wrapper .option span{
        font-size: 20px;
        color: white;
        margin-left: 5px;
    }
    #option-1:checked:checked ~ .option-1 span,
    #option-2:checked:checked ~ .option-2 span{
        color: #fff;
    }

    .nice-select .list{
        border: 1px solid #cccc!important;
    }
    #wizard .nice-select.form-control{
        padding: 8px!important;
    }
    .wrapper .option{
        background: transparent!important;
        border:none!important;

    }
    .cont-box{
        overflow: initial!important;
    }
    #wizard .form-group {
        margin-bottom: 1rem;
        margin-top: 20px;
    }

</style>

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body checkout-tab">
                            <form action="<?php echo e(route('admin.walkingReservation.add')); ?>" id="form_data"  data-cc-on-file="false" data-stripe-publishable-key="<?php echo e(env('STRIPE_KEY')); ?>" class="require-validation" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
<!--                                ===============================-->
<!--                                    My Code-->
<!--                                ===============================-->
                                <div class="wrapper ref">
                                    <form action="">
                                        <div class="step-arrow-nav mt-n3 mx-n3 mb-3">
                                            <div id="wizard">
                                                <!-- SECTION 1 -->
                                                <h4><i class="las la-check-circle"></i> Date</h4>
                                                <section class="sec">
                                                    <div class="row">
                                                        <div class="col-lg-12 offset-lg-0">
                                                            <div class="cont-box">
                                                                <div class="row">

                                                                    <div class="col-lg-4">
                                                                        <div class="form-group">
                                                                            <label>Select Branch</label>
                                                                            <select name="branch" id="" class="form-control" >
                                                                                <option>Adelaide</option>
                                                                                <option>Sydney</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-4">
                                                                        <div class="form-group">
                                                                            <label>Pick Up Location</label>
                                                                            <select class="form-control" name="p_location">
                                                                                <?php $__empty_1 = true; $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                                    <option value="<?php echo e($l['id']); ?>"> <?php echo e($l['name']); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                                    <option value="" hidden>No Location Found</option>
                                                                                <?php endif; ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-4">
                                                                        <div class="form-group">
                                                                            <label>Return Location </label>
                                                                            <select class="form-control" name="r_location">
                                                                                <?php $__empty_1 = true; $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                                    <option value="<?php echo e($l['id']); ?>"> <?php echo e($l['name']); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                                    <option value="" hidden>No Location Found</option>
                                                                                <?php endif; ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-lg-3">
                                                                        <div class="form-group">
                                                                            <label>Pick Up Date</label>
                                                                            <input type="date" name="p_date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>"/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-3">
                                                                        <div class="form-group">
                                                                            <label>Return Date </label>
                                                                            <input type="date" name="r_date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>"/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-3">
                                                                        <div class="form-group">
                                                                            <label>Pick Up Time</label>
                                                                            <input type="time" name="p_time" class="form-control" value=""/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-3">
                                                                        <div class="form-group">
                                                                            <label>Return Time </label>
                                                                            <input type="time" name="r_time" class="form-control" value=""/>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                                <div class="row">

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </section> <!-- SECTION 3 -->
                                                <h4><i class="las la-check-circle"></i> Cars</h4>
                                                <section class="third">
                                                    <div class="row">
                                                        <div class="col-lg-12">
                                                            <div class="card">
                                                                <div class="card-header">
                                                                    <!-- Search box & heading -->
                                                                    <div class="row" style="align-items: center">
                                                                        <div class="col-md-12">
                                                                            <input list="cars" id="searchCar" class="form-control" placeholder="Search Vehicle" onchange="search_car()" onkeyup="search_car()">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="card-body">

                                                                    <div id="show_cars">

                                                                    </div>


                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </section> <!-- SECTION 4 -->
                                                <h4><i class="las la-check-circle"></i> Options</h4>
                                                <section class="third">
                                                    <div class="row">
                                                        <div class="col-lg-12">
                                                            <!-- Option 1 -->
                                                            <div class="card">
                                                                <div class="card-body">
                                                                    <div
                                                                        class="d-flex justify-content-between">
                                                                        <div>
                                                                            <h4>BASIC COVER INCLUDED</h4>
                                                                            <p>If you have an accident or
                                                                                damage
                                                                                the
                                                                                vehicle, your excess
                                                                                liability
                                                                                is
                                                                                $4,818.</p>
                                                                        </div>
                                                                        <span>
                                                                            <a href="#"></a>
                                                                           <span style="color:black;">$<?php echo e((!empty($additional_options[0]['basic_cover'])) ? $additional_options[0]['basic_cover'] : 0); ?> x</span>
                                                                            <input type="number" disabled value="1" name="basic_cover">
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- option 2 -->
                                                            <div class="card">
                                                                <div class="card-body">
                                                                    <div
                                                                        class="d-flex justify-content-between">

                                                                        <div>
                                                                            <h4>Silver Cover</h4>
                                                                            <p>This allows you to reduce the
                                                                                excess liability to $1800.
                                                                                Includes Roadside Assistance
                                                                            </p>
                                                                        </div>
                                                                        <div>
                                                                            <a href="#"></a>
                                                                            <span style="color:black;">$ <?php echo e((!empty($additional_options[0]['silver_cover'])) ? $additional_options[0]['silver_cover'] : 0); ?> x</span>
                                                                            <input type="checkbox" name="silver_cover" value="yes">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- option 3 -->
                                                            <div class="card">
                                                                <div class="card-body">
                                                                    <div
                                                                        class="d-flex justify-content-between">

                                                                        <div>
                                                                            <h4>Gold Cover</h4>
                                                                            <p>This allows you to reduce the
                                                                                excess liability to $0.
                                                                                Includes Roadside Assistance
                                                                            </p>
                                                                        </div>
                                                                        <div>
                                                                            <a href="#"></a>
                                                                            <span style="color:black;">$ <?php echo e((!empty($additional_options[0]['gold_cover'])) ? $additional_options[0]['gold_cover'] : 0); ?> x</span>
                                                                            <input type="checkbox" name="gold_cover" value="yes">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- option 4 -->
                                                            <div class="card">
                                                                <div class="card-body">
                                                                    <div
                                                                        class="d-flex justify-content-between">

                                                                        <div>
                                                                            <h4>Drivers Under 25 and Over 75
                                                                                Years</h4>
                                                                            <p>You MUST select this option
                                                                                if you are under 25 or Over
                                                                                75 years Old. Excess For
                                                                                Drivers <br> under 25 and
                                                                                Over 75
                                                                                is $5000.</p>
                                                                        </div>

                                                                        <div>
                                                                            <a href="#"></a>
                                                                            <span style="color:black;">$ <?php echo e((!empty($additional_options[0]['driver_for'])) ? $additional_options[0]['driver_for'] : 0); ?> x</span>
                                                                            <input type="checkbox" name="driver_for" value="yes">
                                                                        </div>


                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- option 5 -->
                                                            <div class="card">
                                                                <div class="card-body">
                                                                    <div
                                                                        class="d-flex justify-content-between">

                                                                        <div>
                                                                            <h4>Additional Driver</h4>
                                                                            <p>Use this option if there is
                                                                                more then 1 Driver.</p>
                                                                        </div>
                                                                        <div>
                                                                            <a href="#"></a>
                                                                            <span style="color:black;">$ <?php echo e((!empty($additional_options[0]['additional_driver'])) ? $additional_options[0]['additional_driver'] : 0); ?> x</span>
                                                                            <input type="number"
                                                                                   id="quantity"
                                                                                   name="additional_driver" min="1"
                                                                                   max="5">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- option 6 -->
                                                            <div class="card">
                                                                <div class="card-body">
                                                                    <div
                                                                        class="d-flex justify-content-between">

                                                                        <div>
                                                                            <h4>Child Seat</h4>
                                                                            <p>For Children between 0-4
                                                                                Years
                                                                            </p>
                                                                        </div>
                                                                        <div>
                                                                            <a href="#"></a>
                                                                            <span style="color:black;">$ <?php echo e((!empty($additional_options[0]['child_seat'])) ? $additional_options[0]['child_seat'] : 0); ?> x</span>
                                                                            <input type="number"
                                                                                   id="quantity"
                                                                                   name="child_seat" min="1"
                                                                                   max="5">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- option 7 -->
                                                            <div class="card">
                                                                <div class="card-body">
                                                                    <div
                                                                        class="d-flex justify-content-between">

                                                                        <div>
                                                                            <h4>Booster Seat</h4>
                                                                            <p>For Children between 4-8
                                                                                Years</p>
                                                                        </div>
                                                                        <div>
                                                                            <a href="#"></a>
                                                                            <span style="color:black;">$ <?php echo e((!empty($additional_options[0]['boost_seat'])) ? $additional_options[0]['boost_seat'] : 0); ?> x</span>
                                                                            <input type="number"
                                                                                   id="quantity"
                                                                                   name="boost_seat" min="1"
                                                                                   max="5">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </section> <!-- SECTION 4 -->
                                                <h4><i class="las la-check-circle"></i> Customer</h4>
                                                <section class="four">
                                                    <div class="row">
                                                        <div class="accordion" id="accordionPanelsStayOpenExample">
                                                            <div class="accordion-item">
                                                                <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                                                                    <button class="accordion-button" type="button"
                                                                            data-bs-toggle="collapse"
                                                                            data-bs-target="#panelsStayOpen-collapseOne"
                                                                            aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
                                                                        Customer
                                                                    </button>
                                                                </h2>
                                                                <div id="panelsStayOpen-collapseOne">
                                                                    <div class="accordion-body">
                                                                        <div class="row mb-4" style="align-items: center">
                                                                            <div class="col-md-12">
                                                                                <select name="customer" class="form-control">
                                                                                    <?php if(!empty($all_customer)): ?>
                                                                                        <?php $__currentLoopData = $all_customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <option value="<?php echo e($c['id']); ?>"><?php echo e($c['name']); ?></option>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php endif; ?>
                                                                                </select>
                                                                            </div>






                                                                        </div>
                                                                        <!-- form1 Start -->
                                                                        <div class="row" style="display: none" id="cus">

















































































































































































                                                                            <!--end col-->
                                                                        </div> <!-- form1 end -->
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </section>
                                                <h4><i class="las la-check-circle"></i> Agreement</h4>
                                                <section class="five">
                                                    <div class="card license-card">


































































































































































































































































































































































































































































































































































































































































































































                                                        <p style="text-align: center;font-weight: 600;font-size: 21px;margin-top: 10px;">Upload Agreement</p>
                                                        <input style="margin: auto;" type="file" name="agreement">
                                                    </div>
                                                </section> <!-- SECTION 5 -->
                                                <h4><i class="las la-check-circle"></i> Payment</h4>
                                                <section class="six">
                                                    <div class="d-flex" style="justify-content: space-between">
                                                        <div>
                                                            <h5 class="mb-1">Payment Selection</h5>
                                                            <p class="text-muted mb-4">Please select and enter your billing
                                                                information
                                                            </p>
                                                        </div>
                                                        <div>

                                                        </div>
                                                    </div>

                                                    <div class="row g-4">
                                                        <div class="col-lg-6 col-sm-6">
                                                            <div data-bs-toggle="collapse" data-bs-target="#paymentmethodCollapse"
                                                                 aria-expanded="true" aria-controls="paymentmethodCollapse"
                                                                 onclick="showHideTab()">
                                                                <div class="form-check card-radio">
                                                                    <input id="paymentMethod02" name="payment_method" type="radio"
                                                                           class="form-check-input" value="credit_card" checked>
                                                                    <label class="form-check-label" for="paymentMethod02">
                                                            <span class="fs-16 text-muted me-2"><i
                                                                    class="ri-bank-card-fill align-bottom"></i></span>
                                                                        <span class="fs-15 text-wrap">Credit / Debit Card</span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-6 col-sm-6">
                                                            <div data-bs-toggle="collapse" data-bs-target="#paymentMethod03"
                                                                 aria-expanded="false" aria-controls="paymentMethod03"
                                                                 onclick="showHideTab02()">
                                                                <div class="form-check card-radio">
                                                                    <input id="method03" name="payment_method" type="radio"
                                                                           class="form-check-input" value="cod">
                                                                    <label class="form-check-label" for="method03">
                                                            <span class="fs-16 text-muted me-2"><i
                                                                    class="ri-money-dollar-box-fill align-bottom"></i></span>
                                                                        <span class="fs-15 text-wrap">Cash In Store</span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="collapse " id="paymentmethodCollapse">
                                                        <div class="card p-4 border shadow-none mb-0 mt-4">
                                                            <div class="row gy-3">
                                                                <div class="col-md-4">
                                                                    <label for="cc-name" class="form-label">Name on card</label>
                                                                    <input type="text" class="form-control" id="cc-name"
                                                                           placeholder="Enter name">
                                                                    <small class="text-muted">Full name as displayed on card</small>
                                                                </div>

                                                                <div class="col-md-8">
                                                                    <label for="cc-number" class="form-label">Credit card
                                                                        number</label>
                                                                    <input
                                                                        autocomplete='off' class='form-control card-number' size='20'
                                                                        type='text'>
                                                                </div>

                                                                <div class="col-md-3">
                                                                    <label for="cc-expiration" class="form-label">CVC</label>
                                                                    <input autocomplete='off'
                                                                           class='form-control card-cvc' placeholder='ex. 311' size='4'
                                                                           type='text'>
                                                                </div>

                                                                <div class="col-md-3">
                                                                    <label for="cc-expiration" class="form-label">Expiration Month</label>
                                                                    <input
                                                                        class='form-control card-expiry-month' placeholder='MM' size='2'
                                                                        type='text'>
                                                                </div>

                                                                <div class="col-md-3">
                                                                    <label for="cc-cvv" class="form-label">Expiration Year</label>
                                                                    <input class='form-control card-expiry-year' placeholder='YYYY' size='4'
                                                                        type='text'>
                                                                </div>
                                                                <div class='col-md-12 error form-group hide'>
                                                                    <div class='alert-danger alert'>Please correct the errors and try
                                                                        again.
                                                                    </div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                        <div class="text-muted mt-2 fst-italic">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                                 viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                                 stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                                 class="feather feather-lock text-muted icon-xs">
                                                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                                                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                                                            </svg> Your transaction is secured with SSL encryption
                                                        </div>
                                                    </div>
                                                    <div class="collapse" id="paymentMethod03">
                                                        <div class="card p-4 border shadow-none mb-0 mt-4">
                                                            <div class="row gy-3">
                                                                <div class="col-md-12">
                                                                    <label for="cc-name" class="form-label">Amount</label>
                                                                    <input type="number" step="any" class="form-control"
                                                                           placeholder="Enter Amount $" name="total_amount">
                                                                    <small class="text-muted">Enter Rental Amount Total</small>
                                                                </div>


                                                            </div>
                                                        </div>

                                                    </div>

                                                    <div class="d-flex justify-content-end gap-3 mt-4">
                                                        <!-- <button type="button" class="btn btn-light btn-label previestab"
                                                            data-previous="pills-bill-dates-tab"><i
                                                                class="ri-arrow-left-line label-icon align-middle fs-16 me-2"></i>Back
                                                            to Shipping</button>
                                                        <button type="button"
                                                            class="btn btn-primary btn-label right ms-auto nexttab"
                                                            data-nexttab="pills-payment-tab"><i
                                                                class="ri-shopping-basket-line label-icon align-middle fs-16 ms-2"></i>Complete
                                                            Order</button> -->






                                                        <!-- Modal -->
                                                        <div class="modal fade " id="staticBackdrop" data-bs-backdrop="static"
                                                             data-bs-keyboard="false" tabindex="-1"
                                                             aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                            <div class="modal-dialog modal-lg card">
                                                                <div class="modal-content">
                                                                    <div class="modal-header card-header">
                                                                        <h3 class="modal-title" id="staticBackdropLabel">Invoice
                                                                        </h3>
                                                                        <button type="button" class="btn-close"
                                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                                    </div>
                                                                    <div class="modal-body card-body">
                                                                        <div>
                                                                            <div>
                                                                                <div class="row invo-header">
                                                                                    <div class="col-sm-6">
                                                                                        <div class="media">
                                                                                            <div class="media-left">
                                                                                                <!-- <a href="#"><img
                                                                                                        class="media-object img-60"
                                                                                                        src="../assets/images/logo/logo-1.png"
                                                                                                        alt=""></a> -->
                                                                                            </div>
                                                                                            <div class="media-body m-l-20">
                                                                                                <h4 class="media-heading f-w-600">
                                                                                                    Walter White</h4>
                                                                                                <p>
                                                                                                    walterWhite@gmail.com<br>
                                                                                        <span class="digits">Sydney
                                                                                            Branch</span>
                                                                                                </p>
                                                                                            </div>
                                                                                        </div>
                                                                                        <!-- End Info-->
                                                                                    </div>
                                                                                    <div class="col-sm-6">
                                                                                        <div class="text-md-end text-xs-center">
                                                                                            <h3>Invoice #<span
                                                                                                    class="digits counter">0420</span>
                                                                                            </h3>
                                                                                            <p>
                                                                                                Issued: May<span class="digits"> 27,
                                                                                        2022</span><br>
                                                                                                Payment Due: June <span
                                                                                                    class="digits">27, 2021</span>
                                                                                            </p>
                                                                                        </div>
                                                                                        <!-- End Title                                 -->
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <!-- End InvoiceTop-->

                                                                            <!-- End Invoice Mid-->
                                                                            <div>
                                                                                <div class="table-responsive invoice-table"
                                                                                     id="table">
                                                                                    <table
                                                                                        class="table table-bordered table-striped">
                                                                                        <tbody>
                                                                                        <tr>
                                                                                            <td>
                                                                                                <h6 class="p-2 mb-0">Car
                                                                                                    Description</h6>
                                                                                            </td>

                                                                                            <td>
                                                                                                <h6 class="p-2 mb-0">Rate
                                                                                                </h6>
                                                                                            </td>
                                                                                        </tr>

                                                                                        <tr>
                                                                                            <td>
                                                                                                <label>Car Name</label>
                                                                                                <p class="m-0">Lorem Ipsum is
                                                                                                    simply dummy text of the
                                                                                                    printing and typesetting
                                                                                                    industry.</p>
                                                                                            </td>


                                                                                            <td>
                                                                                                <p>
                                                                                                    AU$500.00</p>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td>
                                                                                                <label>Car Name</label>
                                                                                                <p class="m-0">Lorem Ipsum is
                                                                                                    simply dummy text of the
                                                                                                    printing and typesetting
                                                                                                    industry.</p>
                                                                                            </td>

                                                                                            <td>
                                                                                                <p>
                                                                                                    AU$500.00</p>
                                                                                            </td>
                                                                                        </tr>

                                                                                        <tr>

                                                                                            <td>
                                                                                                <h6 class="mb-0 p-2">Grand Total
                                                                                                </h6>
                                                                                            </td>
                                                                                            <td>
                                                                                                <h6 class="mb-0 p-2">AU$1,000.00
                                                                                                </h6>
                                                                                            </td>
                                                                                        </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </div>
                                                                                <!-- End Table-->

                                                                            </div>
                                                                            <!-- End InvoiceBot-->
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer card-footer">
                                                                        <button type="button" class="btn btn-primary">Print</button>
                                                                        <button type="button" class="btn btn-primary">Send
                                                                            Email</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </section> <!-- SECTION 6 -->
                                                <h4><i class="las la-check-circle"></i> Inception</h4>
                                                <section class="seven">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="card">
                                                                <div class="card-header">
                                                                    <h4 class="card-title">Return Checking</h4>
                                                                </div>
                                                                <div class="card-body" style="padding: 2rem;">
                                                                    <!-- upload images start -->
                                                                    <div class="card">
                                                                        <div class="card-header">
                                                                            <h5 class="card-title mb-0">Drop Images</h5>
                                                                        </div><!-- end card header -->

                                                                        <div class="card-body">
                                                                            <p class="text-muted">Drop Your Car Images</p>


                                                                                <input name="image" type="file" data-height="300" />


                                                                        </div>
                                                                        <!-- end card body -->
                                                                    </div>

                                                                <textarea name="comments" id="checking-comments"
                                                                  cols="15" rows="5" class="form-control"
                                                                  placeholder="comments.."></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </section> <!-- SECTION 8 -->
                                                <h4><i class="las la-check-circle"></i> Confirm</h4>
                                                <section class="eight">
                                                    <div class="card">
                                                        <div class="card-header">
                                                            <h5 class="card-title">Summary</h5>
                                                        </div>
                                                        <div class="card ribbon-box border shadow-none mb-lg-0">
                                                            <div class="card-body">
                                                                <div class="ribbon ribbon-primary round-shape">Customer Info</div>


                                                                <div class="ribbon-content mt-4 text-muted">
                                                                    <div id="show_customer_info"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="card ribbon-box border shadow-none mb-lg-0">
                                                            <div class="card-body">
                                                                <div class="ribbon ribbon-primary round-shape">Booking Info</div>
                                                                <div id="booking_info"></div>
                                                            </div>
                                                        </div>

                                                        <div class="card ribbon-box border shadow-none mb-lg-0">
                                                            <div class="card-body">
                                                                <div class="ribbon ribbon-primary round-shape">Vehicle</div>
                                                                <div class="ribbon-content mt-4 text-muted">
                                                                    <div id="show_vehicle_info"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="card ribbon-box border shadow-none mb-lg-0">
                                                            <div class="card-body">
                                                                <div class="ribbon ribbon-primary round-shape">Payment</div>
                                                                <div class="ribbon-content mt-4 text-muted">
                                                                    <div id="payment_info"></div>
                                                                </div>
                                                            </div>
                                                        </div>











































                                                    </div>
                                                </section> <!-- SECTION 8 -->
                                            </div>
                                        </div>
                                    </form>
                                </div>
<!--                                -------------------------------------->
                            </form>
                        </div>
                        <!-- end card body -->
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
        </div>
    </div>
</div>



<script src="<?php echo e(url('assets')); ?>/js/frm-wiz/json2.min.js"></script>
<script src="<?php echo e(url('assets')); ?>/js/frm-wiz/jquery.signaturepad.js"></script
<script src="<?php echo e(url('assets')); ?>/js/frm-wiz/jquery.nice-select.js"></script>
<script src="<?php echo e(url('assets')); ?>/js/frm-wiz/jquery.steps.min.js"></script>
<script src="<?php echo e(url('assets')); ?>/js/frm-wiz/dropify.js"></script>

<script type="text/javascript" src="<?php echo e(url('assets')); ?>/js/frm-wiz/moment.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('assets')); ?>/js/frm-wiz/daterangepicker.js"></script>
<script type="text/javascript" src="<?php echo e(url('assets')); ?>/js/frm-wiz/jquery.nice-select.js"></script>
<script src="<?php echo e(url('assets')); ?>/js/frm-wiz/my-js.js"></script>
<script>


function showDriverName() {
    let catchSelectId = document.getElementById('driver');
    let driver = document.getElementById('driverBlock');
    if (catchSelectId.options[catchSelectId.selectedIndex].value == "with") {
        driver.style.display = 'inline-block';
    } else {
        driver.style.display = 'none';
    }
}

function showHideTab() {
    let idTab1 = document.getElementById('paymentmethodCollapse');
    let idTab2 = document.getElementById('paymentMethod03');
    idTab1.style.display = 'block';
    idTab2.style.display = 'none';
}
showHideTab()

function showHideTab02() {
    let idTab1 = document.getElementById('paymentmethodCollapse');
    let idTab2 = document.getElementById('paymentMethod03');
    idTab2.style.display = 'block';
    idTab1.style.display = 'none';
}



function search_car(){
    let car = $("#searchCar").val();
    if (car.length >0 && car !== ' '){
        let _token = "<?php echo e(csrf_token()); ?>";
        $.post("<?php echo e(route('admin.walking_reservation.getCar')); ?>",{_token,car},function (resp){
            let check = resp.trim();
            if(check.length==0){
                $("#show_cars").html("No car Found")
            }else{
                $("#show_cars").html(resp)
            }
        })
    }else{
        $("#show_cars").html(" ")
    }
}

$(document).ready(function () {
    $('#li').click(function () {
        $(":input", this).prop('checked', true);
    });
    $("#wizard").steps({
        headerTag: "h4",
        bodyTag: "section",
        transitionEffect: "fade",
        enableAllSteps: true,
        transitionEffectSpeed: 500,
        onStepChanging: function (event, currentIndex, newIndex) {

            //getting form data
            let p_location = $("[name='p_location'] option:selected").html();
            let r_location = $("[name='r_location'] option:selected").html();
            let p_date = $("[name='p_date']").val();
            // let r_date = $("[name='r_date']").val();
            let p_time = $("[name='p_time']").val();
            let r_time = $("[name='r_time']").val();
            let payment_method = $("[name='payment_method']").val();
            let total_amount = $("[name='total_amount']").val();
            if ( newIndex === 1 ) {
                $('.steps ul').addClass('step-2');
            }
            if ( newIndex === 2 ) {
                $('.steps ul').addClass('step-3');
                let vehicle_id = $("[name='shab_car']").val();
                let _token  = '<?php echo e(csrf_token()); ?>';
                $.post("<?php echo e(url('admin/walkingReservation/getAjaxData/vehicle')); ?>",{_token,vehicle_id},function (e){
                    $("#show_vehicle_info").html(e)
                })
            }
            if ( newIndex === 6 ) {
                var radioValue = $("input[name='payment_method']:checked").val();
                if (radioValue === 'credit_card'){
                    let check = stripe();
                    if (check == undefined){
                        return true;
                    }else{
                        return false;
                    }
                }
            else{
                    return true
                }
            }
            if ( currentIndex === 6 ) {
                let booking_info = `<div class="ribbon-content mt-4 text-muted">
                <div class="row">
                <div class="col-md-4">
                <label for="name">Pickup Date: </label>
                <p>${p_date}</p>
                </div>
                <div class="col-md-4">
                <label for="email">Pickup Location: </label>
                <p>${p_location}</p>
                </div>
                <div class="col-md-4">
                <label for="invoice">Pickup Time: </label>
                <p>${p_time}</p>
                </div>
                <div class="col-md-4">
                <label for="b-name">Return Time: </label>
                <p>${r_time}</p>
                </div>
                <div class="col-md-4">
                <label for="name">Return Location: </label>
                <p>${r_location}</p>
                </div>

                </div>
                </div>`
                let payment_info = `
                <div class="row">
                <div class="col-md-4">
                <label for="name">Payment Type: </label>
                <p>${payment_method}</p>
                </div>
                <div class="col-md-4">
                <label for="name">Total Amount: </label>
                <p>$ ${total_amount}</p>
                </div>
                </div>
                `;

                $("#payment_info").html(payment_info)
                $("#booking_info").html(booking_info)
                let customer_id = $("[name='customer']").val();
                let _token  = '<?php echo e(csrf_token()); ?>';
                $.post("<?php echo e(url('admin/walkingReservation/getAjaxData/customer')); ?>",{_token,customer_id},function (e){
                    $("#show_customer_info").html(e);
                })
            }
            else {
                $('.steps ul').removeClass('step-3');
            }
            return true;
        },
        onFinishing: function (event, currentIndex) {
            $("#form_data").submit();
        },
        labels: {
            finish: "Confirm",
            next: "Next",
            previous: "Previous"
        }
    });
    // Custom Steps Jquery Steps
    $('.wizard > .steps li a').click(function(){
        $(this).parent().addClass('checked');
        $(this).parent().prevAll().addClass('checked');
        $(this).parent().nextAll().removeClass('checked');
    });
    // Custom Button Jquery Steps
    $('.forward').click(function(){
        $("#wizard").steps('next');
    })
    $('.backward').click(function(){
        $("#wizard").steps('previous');
    })
    // Checkbox
    $('.checkbox-circle label').click(function(){
        $('.checkbox-circle label').removeClass('active');
        $(this).addClass('active');
    })
});

</script>

<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<script type="text/javascript">
    function stripe() {
        var $form = $(".require-validation");
        var $form1 = $(".require-validation"),
            inputSelector = ['input[type=email]', 'input[type=password]',
                'input[type=text]', 'input[type=file]',
                'textarea'
            ].join(', '),
            $inputs = $form.find('.required').find(inputSelector),
            $errorMessage = $form.find('div.error'),
            valid = true;
        $errorMessage.addClass('hide');
        $('.has-error').removeClass('has-error');
        $inputs.each(function(i, el) {
            var $input = $(el);
            if ($input.val() === '') {
                $input.parent().addClass('has-error');
                $errorMessage.removeClass('hide');
                e.preventDefault();
            }
        });
        if (!$form.data('cc-on-file')) {
            // e.preventDefault();
            Stripe.setPublishableKey($form.data('stripe-publishable-key'));
            Stripe.createToken({
                number: $('.card-number').val(),
                cvc: $('.card-cvc').val(),
                exp_month: $('.card-expiry-month').val(),
                exp_year: $('.card-expiry-year').val()
            }, stripeResponseHandler);
        }
        function stripeResponseHandler(status, response) {
            if (response.error) {
                $('.error')
                    .removeClass('hide')
                    .find('.alert')
                    .text(response.error.message);
            } else {
                /* token contains id, last4, and card type */
                var token = response['id'];
                $form1.find('input[type=text]').empty();
                $form1.append("<input type='hidden' name='stripeToken' value='" + token + "'/>");
            }
        }
        // return true
    };
</script>

<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\xampp\htdocs\laravel\simba\resources\views/admin/create_Walkin_Reservation.blade.php ENDPATH**/ ?>