<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- Container Fluid Reservation section content-->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-bottom-dashed">
                            <div class="row g-4 align-items-center">
                                <div class="col-sm">
                                    <div>
                                        <h5 class="card-title mb-0">View All Vehicles</h5>
                                    </div>

                                </div>
                                <div class="col-sm-auto">
                                    <a href="#" class="btn btn-primary">Print</a>
                                </div>
                            </div>
                        </div>
                        <!-- card Header end -->

                        <!-- Search Form end -->
                        <div class="card-body">
                            <div>
                                <div class="table-responsive table-card mb-1">
                                    <table class="table align-middle" id="customerTable">
                                        <thead class="table-light text-muted">
                                        <tr>
                                            <th scope="col" style="width: 50px;">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="checkAll"
                                                           value="option">
                                                </div>
                                            </th>
                                             <th>REG No</th>
                                            <th>Brand</th>
                                            <th>Model</th>
                                            <th>Type</th>
                                            <th>Year</th>
                                            <th>Colour</th>
                                            <th>Vin Number</th>
                                            <th>Engine No</th>
                                            <th>Finance</th>
                                            <th>Category</th>
                                            <th>Branch</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody class="list form-check-all ">
                                        <?php if(!empty($all_vehicles)): ?>
                                            <?php $__currentLoopData = $all_vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                            <th scope="row">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="checkAll"
                                                           value="option1">
                                                </div>
                                            </th>

                                            <td><?php echo e($v->reg_number); ?></td>
                                            <td><?php echo e($v->brand); ?></td>
                                            <td><?php echo e($v->model); ?></td>
                                            <td><?php echo e($v->type); ?></td>
                                            <td><?php echo e($v->year); ?></td>
                                            <td><?php echo e($v->color); ?></td>
                                            <td><?php echo e($v->win_no); ?></td>
                                            <td><?php echo e($v->engine_no); ?></td>
                                            <td><?php echo e($v->finance); ?></td>
                                            <td><?php echo e($v->category); ?></td>
                                            <td><?php echo e($v->branch); ?></td>
                                            <td>
                                                <ul class="list-inline hstack gap-2 mb-0">
                                                    <li class="list-inline-item view detail" data-bs-toggle="tooltip"
                                                        data-bs-trigger="hover" data-bs-placement="top" title=""
                                                        data-bs-original-title="view detail">
                                                        <a href="<?php echo e(url('admin/vehicle/view/car-detail/'.$v->id)); ?>"
                                                           class="text-primary d-inline-block edit-item-btn">
                                                            <i class="ri-eye-fill fs-16"></i>
                                                        </a>
                                                    </li>
                                                    <li class="list-inline-item edit" data-bs-toggle="tooltip"
                                                        data-bs-trigger="hover" data-bs-placement="top" title=""
                                                        data-bs-original-title="Edit">
                                                        <a href="#showModal" data-bs-toggle="modal"
                                                           class="text-primary d-inline-block edit-item-btn">
                                                            <i class="ri-pencil-fill fs-16"></i>
                                                        </a>
                                                    </li>
                                                    <li class="list-inline-item" data-bs-toggle="tooltip"
                                                        data-bs-trigger="hover" data-bs-placement="top" title=""
                                                        data-bs-original-title="Remove">
                                                        <a class="text-danger d-inline-block remove-item-btn" onclick="delete_('<?php echo e(url('admin/vehicle/remove/'.$v->id)); ?>')">
                                                            <i class="ri-delete-bin-5-fill fs-16"></i>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </td>
                                        </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                    <div class="noresult" style="display: none">
                                        <div class="text-center">
                                            <lord-icon src="https://cdn.lordicon.com/msoeawqm.json" trigger="loop"
                                                       colors="primary:#121331,secondary:#08a88a"
                                                       style="width:75px;height:75px">
                                            </lord-icon>
                                            <h5 class="mt-2">Sorry! No Result Found</h5>
                                            <p class="text-muted mb-0">We've searched more than 150+ Orders We did not
                                                find any
                                                orders for you search.</p>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\xampp\htdocs\laravel\simba\resources\views/admin/viewAllVehicles.blade.php ENDPATH**/ ?>