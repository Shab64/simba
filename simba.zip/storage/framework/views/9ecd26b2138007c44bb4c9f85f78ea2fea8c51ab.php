<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Asad Code Start -->
<style>
    /* .btn-group .add-reservation::before{
    position:absolute;
    background-color:#ed981f;
    background-color:red;
    content:"";
    width:0%;
    height:100%;
    top:0;
    left:0;
    transition:0.1s all linear;
} */
    table.dataTable thead .sorting {
    text-align: initial;
    background-color: #d8deff;
    font-size:11px;
    color: black;
}
table.dataTable tbody th, table.dataTable tbody td {
    font-size: 11px;
    padding: 8px 10px;
}
.customer-name h6{
    font-size:11px;
    font-weight: 400;
    color: #545454;
}
table.dataTable tbody th, table.dataTable tbody td {
    border-right: 1px solid #cccccc;
    font-size: 10px;
    padding: 8px 10px;
}
.btn-group .add-reservation{
    background-color:#ec971f;
    /* color:#283891; */
    color:white;
    font-weight:500;
    border:none;
    position:relative;
}
.btn-group .add-reservation{
    position:relative;
    transition:0.3s all ease-in;

}

.btn-group .add-reservation:hover{
    background-color:#f0ad4e;
}
.btn-group>.btn-group:not(:last-child)>.btn, .btn-group>.btn:not(:last-child):not(.dropdown-toggle) {
    border: none;
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
}
.btn-group .print-icon{
    background-color:#d9d9d9;
    border:1px solid black;
    color:black;
    font-size:20px;
    display:flex;
    border:none!important;
    transition:0.3s all ease-in;
}
.btn-group .btn.print-icon:hover{
    background-color:#b7b7b7!important;
    border:none!important;
}
.btn-group .quotation{

}
.btn-group .quotation:hover{
    background-color:#3547b1;
}
.dataTables_wrapper .dataTables_length {
    position: absolute;
    bottom: -3px;
}
#myDatatable_info {
    position: relative;
    left: 170px;
}
#myDatatable_filter{
    display:none;
}
.table-card td:first-child, .table-card th:first-child {
    width: 0px!important;
    padding-left: 16px;
}
.top-filter{
    padding:20px 0px 10px 0px;
}
.daterangepicker {
    background-color:#f2f2f2;
}
.same-btn {
    width: 100%;
    background-color: #d9d9d9;
    color: black;
}
.same-btn:hover{
    background-color:#b7b7b7!important;
    color:white;
    border:none!important
}

/* .drp-calendar.left{
    box-shadow: -10px -13px 22px -8px rgba(0,0,0,0.75);
-webkit-box-shadow: -10px -13px 22px -8px rgba(0,0,0,0.75);
-moz-box-shadow: -10px -13px 22px -8px rgba(0,0,0,0.75);
}
.drp-calendar.right{
    box-shadow: 10px 13px 22px -8px rgba(0,0,0,0.75);
-webkit-box-shadow: 10px 13px 22px -8px rgba(0,0,0,0.75);
-moz-box-shadow: 10px 13px 22px -8px rgba(0,0,0,0.75);
} */
</style>
<!-- Asad Code End -->

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- Container Fluid Reservation section content-->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-bottom-dashed">

                            <div class="row g-4 align-items-center">
                                <div class="col-sm">
                                    <div>
                                        <h5 class="card-title mb-0">Rental Reservations</h5>
                                    </div>
                                </div>
                                <div class="col-sm-auto">
                                <div class="btn-group">
                                        <a href="javascript:window.print()" class="btn btn-primary print-icon"><i class="las la-print"></i></a>
                                        <a href="<?php echo e(url('admin/quotation/view/view-all-quotation')); ?>" class="btn btn-primary quotation">Quotation</a>
                                        <a href="<?php echo e(url('admin/add_reservation')); ?>" class="btn btn-primary add-reservation">Add Reservation</a>
                                    </div>

<!--                                    <div class="btn-group">-->
<!--                                        <button type="button" class="btn btn-primary add-btn dropdown-toggle"-->
<!--                                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Add-->
<!--                                            Reservation-->
<!--                                        </button>-->
<!--                                        <div class="dropdown-menu">-->
<!--                                            <a class="dropdown-item" href="create_Walkin_Reservation.blade.backup"><i-->
<!--                                                    class="ri-add-line align-bottom me-1"></i>Walk In Reservation</a>-->
<!--                                            <a class="dropdown-item" href="createOnlineReservation.php"><i-->
<!--                                                    class="ri-add-line align-bottom me-1"></i>Online-->
<!--                                                Reservation</a>-->
<!--                                        </div>-->
<!---->
<!--                                    </div>-->
                                </div>


                                <!-- Asad Code Start -->
                               <div class="top-filter">
                               <div class="row p-0 m-0">
                                            <div class="col-md-2 ">
                                                    <select class="form-control" data-trigger="" name="status-field"
                                                        id="status-field">
                                                        <option value="">Branch</option>
                                                        <option value="Sydney">Sydney</option>
                                                        <option value="Adelaide">Adelaide</option>
                                                    </select>
                                            </div>
                                            <div class="col-md-2">
                                                    <select class="form-control" data-trigger="" name="status-field"
                                                        id="status-field">
                                                        <option value="">Status</option>
                                                        <option value="Rental">Rental</option>
                                                        <option value="Long Rental">Long Rental</option>
                                                        <option value="Open">Open</option>
                                                        <option value="Closed">Closed</option>
                                                    </select>
                                            </div>
                                            <div class="col-md-3">
                                                <input type="text" name="daterange" value="01/01/2018 - 01/15/2018" class="form-control" >
                                            </div>

                                            <div class="col-md-2">
                                            <select class="form-control" data-trigger="" name="status-field"
                                                        id="status-field">
                                                        <option value="">Payment Status</option>
                                                        <option value="Sydney">Paid</option>
                                                        <option value="Adelaide">Pending</option>
                                                    </select>
                                            </div>
                                            <div class="col-md-3" >
                                                <div class="row p-0 m-0">
                                                    <div class="col-md-6 p-0 m-0" >
                                                    <span class="reset-btn">
                                                    <a href="javascript:;"  class="btn btn-primary same-btn" >Reset</a>
                                                </span>
                                                    </div>
                                                    <div class="col-md-6 p-0 m-0" >
                                                    <span class="filter-btn">
                                                    <a href="javascript:;" class="btn btn-primary same-btn"  >Filter</a>
                                                </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                            </div>
                               </div>
                            <!-- Asad Code End -->


                        </div>
                        <div class="card-body">
                            <div>
                                <div class="table-responsive table-card mb-1">
                                    <table class="table align-middle" id="myDatatable">
                                        <thead class="table-light text-muted">
                                            <tr>
                                                <th scope="col" style="width: 50px;">
                                                    S.N
                                                </th>

                                                <!-- <th>Customer Name</th>
                                                <th>Vehicle</th>
                                                <th>Branch</th>
                                                <th>Pickup Date</th>
                                                <th>Return Date</th> -->

                                                <!-- Asad End -->
                                                <th>Branch</th>
                                                <th>Customer Name</th>
                                                <th>Pickup Date</th>
                                                <th>Return Date</th>
                                                <th>Pickup Location</th>
                                                <th>Vehicle</th>
                                                <th>Total Price</th>
                                                <th>Total Paid</th>
                                                <th>Outstanding Balance</th>
                                                <th>Status</th>
                                                <th>Remaining Days</th>
                                                <th>Daily Price</th>
                                                <!-- Asad End -->
                                                
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody class="list form-check-all ">
                                        <?php $__empty_1 = true; $__currentLoopData = $all_reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <?php
                                                $earlier = new DateTime($r['p_date']);
                                                $later = new DateTime($r['r_date']);
                                                $remaining_days = $later->diff($earlier)->format("%a");
                                            ?>
                                            <tr>
                                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                <td><?php echo e($r['customer_details'][0]['name']); ?></td>
                                                <td class="customer-name"><h6><?php echo e($r['car_details'][0]['name']); ?></h6></td>
                                                <!-- Asad Start -->
                                                <td><?php echo e($r['p_date']); ?></td>
                                                <td><?php echo e($r['r_date']); ?></td>
                                                <td><?php echo e($r['p_location'][0]['name']); ?></td>
                                                <td><?php echo e((!empty($r['vehicle'])) ? $r['vehicle'][0]['brand'] : "-"); ?></td>
                                                <td>$<?php echo e($r['total_amount']); ?></td>
                                                <td>$<?php echo e($r['paid_amount']); ?></td>
                                                <td>$<?php echo e($r['remaining_amount']); ?></td>
                                                <!-- Asad End -->
                                                <td><?php echo e(($remaining_days== 0) ? "Reservation Ended" : "Rental"); ?></td>
                                                <td style="color: <?php echo e(($remaining_days <=0) ? "red"  : "green"); ?>;font-weight: bold"><?php echo e($remaining_days); ?></td>
                                                <td>$<?php echo e($r['car_details'][0]['daily_start_price']); ?></td>
                                                
                                                
                                                
                                                <td>
                                                    <ul class="list-inline hstack gap-2 mb-0">
                                                        <li class="list-inline-item view detail" data-bs-toggle="tooltip"
                                                            data-bs-trigger="hover" data-bs-placement="top" title=""
                                                            data-bs-original-title="view detail">
                                                            <a href="<?php echo e(url('admin/reservation/view/return/'.$r['id'])); ?>"
                                                               class="text-primary d-inline-block edit-item-btn">
                                                                <i class="ri-eye-fill fs-16"></i>
                                                            </a>
                                                        </li>

                                                        <li class="list-inline-item" data-bs-toggle="tooltip"
                                                            data-bs-trigger="hover" data-bs-placement="top" title=""
                                                            data-bs-original-title="Remove">
                                                            <a class="text-danger d-inline-block remove-item-btn"
                                                               data-bs-toggle="modal"
                                                               data-bs-target="#deleteRecordModal">
                                                                <i class="ri-delete-bin-5-fill fs-16"></i>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>

                                </div>

                            </div>
                            <div class="modal fade" id="showModal" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header bg-light p-3">
                                            <h5 class="modal-title" id="exampleModalLabel"></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close" id="close-modal"></button>
                                        </div>
                                        <form action="#">
                                            <div class="modal-body">
                                                <input type="hidden" id="id-field">

                                                <div class="mb-3" id="modal-id" style="display: none;">
                                                    <label for="id-field1" class="form-label">ID</label>
                                                    <input type="text" id="id-field1" class="form-control"
                                                        placeholder="ID" readonly="">
                                                </div>

                                                <div class="mb-3">
                                                    <label for="customername-field" class="form-label">Customer
                                                        Name</label>
                                                    <input type="text" id="customername-field" class="form-control"
                                                        placeholder="Enter Name" required="">
                                                </div>

                                                <div class="mb-3">
                                                    <label for="email-field" class="form-label">Email</label>
                                                    <input type="email" id="email-field" class="form-control"
                                                        placeholder="Enter Email" required="">
                                                </div>

                                                <div class="mb-3">
                                                    <label for="phone-field" class="form-label">Phone</label>
                                                    <input type="text" id="phone-field" class="form-control"
                                                        placeholder="Enter Phone no." required="">
                                                </div>

                                                <div class="mb-3">
                                                    <label for="date-field" class="form-label">Joining Date</label>
                                                    <input type="date" id="date-field" class="form-control"
                                                        data-provider="flatpickr" data-date-format="d M, Y" required="">
                                                </div>

                                                <div>
                                                    <label for="status-field" class="form-label">Status</label>
                                                    <select class="form-control" data-trigger="" name="status-field"
                                                        id="status-field">
                                                        <option value="">Status</option>
                                                        <option value="Active">Active</option>
                                                        <option value="Block">Block</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="hstack gap-2 justify-content-end">
                                                    <button type="button" class="btn btn-light"
                                                        data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-success" id="add-btn">Add
                                                        Customer</button>
                                                    <button type="button" class="btn btn-success"
                                                        id="edit-btn">Update</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal -->
                            <div class="modal fade zoomIn" id="deleteRecordModal" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close" id="btn-close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mt-2 text-center">
                                                <lord-icon src="https://cdn.lordicon.com/gsqxdxog.json" trigger="loop"
                                                    colors="primary:#f7b84b,secondary:#f06548"
                                                    style="width:100px;height:100px"></lord-icon>
                                                <div class="mt-4 pt-2 fs-15 mx-4 mx-sm-5">
                                                    <h4>Are you sure ?</h4>
                                                    <p class="text-muted mx-4 mb-0">Are you sure you want to remove this
                                                        record ?</p>
                                                </div>
                                            </div>
                                            <div class="d-flex gap-2 justify-content-center mt-4 mb-2">
                                                <button type="button" class="btn w-sm btn-light"
                                                    data-bs-dismiss="modal">Close</button>
                                                <button type="button" class="btn w-sm btn-danger "
                                                    id="delete-record">Yes, Delete It!</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--end modal -->
                        </div>
                    </div>

                </div>
                <!--end col-->
            </div>
            <!-- row end -->
        </div>
    </div>
</div>
<!-- End Page-content -->
<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\xampp\htdocs\laravel\simba\resources\views/admin/reservations.blade.php ENDPATH**/ ?>