<?php echo $__env->make('users.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<section class="product-listing page-section-ptb">
    <div class="container">
        <div class="row">

            <div class="col-lg-12 col-md-8">
                <div class="sorting-options-main">
                    <div class="row">


                        <div class="col-lg-12">
                            <div class="price-search">
                                <span class="mb-2">Price search</span>
                                <div class="search">
                                    <i class="fa fa-search"></i>
                                    <input type="search" class="form-control placeholder" placeholder="Search....">
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <?php $__empty_1 = true; $__currentLoopData = $our_fleet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="car-grid">
                    <div class="row">
                        <div class="col-lg-4 col-md-12">
                            <div class="car-item gray-bg text-center">
                                <div class="car-image">
                                    <img class="img-fluid" src="<?php echo e(url('storage/app/public/carlist/'.$o['image'])); ?>" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-12">
                            <div class="car-details">
                                <div class="car-title">
                                    <a href="#"><?php echo e($o['name']); ?></a>
                                    <p><?php echo e($o['details']); ?></p>
                                </div>
                                <div class="price">

                                    <span class="new-price">$<?php echo e($o['daily_start_price']); ?></span>
                                    <a class="button red float-end" href="<?php echo e(route('our-fleet-detail',[$o['id']])); ?>">Details</a>
                                </div>
                                <div class="car-list">
                                    <ul class="list-inline">
                                        <li><i class="fa fa-registered"></i> 2016</li>
                                        <li><i class="fa fa-cog"></i> Manual</li>
                                        <li><i class="fa fa-shopping-cart"></i> Compact</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    No Car Found
                <?php endif; ?>
                <div class="pagination-nav d-flex justify-content-center">
                    <ul class="pagination">
                        <li><a href="#">«</a></li>
                        <li class="active"><a href="#">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a href="#">5</a></li>
                        <li><a href="#">»</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>


<?php echo $__env->make('users.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\xampp\htdocs\laravel\simba\resources\views/users/our-fleet.blade.php ENDPATH**/ ?>