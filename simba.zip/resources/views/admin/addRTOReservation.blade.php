@include('admin.header')
<!-- dropzone css -->
<link rel="stylesheet" href="{{url('assets')}}/libs/dropzone/dropzone.css" type="text/css" />

<style>
.card-cars {
    /*box-shadow: rgba(67, 71, 85, 0.27) 0px 0px 0.25em, rgba(90, 125, 188, 0.05) 0px 0.25em 1em;*/
    cursor: pointer;
    transition: .8s;
    transition: transform .8s;
    background-color: aliceblue;
    margin-top: 55px;
    text-align: center;
}

.card-cars:hover {
    /* transform: scale(1.03); */
    transform: translateY(-5px);
    transition: .8s;


}

.card-cars:hover .car {
    box-shadow: 0px 0px 25px #e7e7e7;
}

.ribbon-content label{
    color:black;
}
.ribbon-box .card-body{
    margin-top: 12px;
}

.license-card {
    height: 70vh;
    overflow-y: scroll;
    box-shadow: rgba(67, 71, 85, 0.27) 0px 0px 0.25em, rgba(90, 125, 188, 0.05) 0px 0.25em 1em;

}

.img-figure-tag {
    /*border-radius: 25px;*/
    /*box-shadow: rgba(67, 71, 85, 0.27) 0px 0px 0.25em, rgba(90, 125, 188, 0.05) 0px 0.25em 1em;*/

}

.img-hover {
    transition: transform .8s;
}

.img-hover:hover {
    transform: scale(1.06);
}

.header-aggrement-main-div {
    align-items: center;
}

.agrement-header {
    text-align: start;

}

#pills-checking input[type=text] {
    margin-bottom: 20px;
}

.car {
    width: 400px;
    margin: 0px auto;
    border-radius: 19px;
    background: aliceblue;
    position: relative;
    bottom: 30px;
    text-align: center;
    box-shadow: 0px 0px 15px #e7e7e7;
}

.car img {
    text-align: center;
}

.card-cars .card-title {
    font-size: 23px !important;
    text-align: center;
    font-weight: 700 !important;
}

.card-cars .card-body {
    padding-left: 0;
    padding-right: 0;
    padding-bottom: 0;
}

.card-cars button {
    width: 100%;
    border-radius: 0;
}

.text-start {
    text-align: start;
}


@media (max-width:767px) {
    .car {
        width: 100%;
        margin: 0px auto;
        border-radius: 19px;
        background: aliceblue;
        position: relative;
        bottom: 30px;
        text-align: center;
        box-shadow: 0px 0px 15px #e7e7e7;
    }

}
</style>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body checkout-tab">
                            <form action="#">
                                <div class="step-arrow-nav mt-n3 mx-n3 mb-3">
                                    <ul class="nav nav-pills nav-justified custom-nav" role="tablist">

                                        <!-- Dates Tab Start -->

                                        <!-- Cars Tab Start -->
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link fs-15 p-3 active" id="pills-cars-tab"
                                                data-bs-toggle="pill" data-bs-target="#pills-cars" type="button"
                                                role="tab" aria-controls="pills-cars" aria-selected="false"
                                                data-position="1"><i
                                                    class="ri-checkbox-circle-line fs-16 p-2 bg-soft-primary text-primary rounded-circle align-middle me-2"></i>
                                                Cars</button>
                                        </li>
                                        <!-- Customer Tab Start -->
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link fs-15 p-3" id="pills-bill-customer-tab"
                                                data-bs-toggle="pill" data-bs-target="#pills-bill-customer"
                                                type="button" role="tab" aria-controls="pills-bill-customer"
                                                aria-selected="false" data-position="2"><i
                                                    class="ri-checkbox-circle-line fs-16 p-2 bg-soft-primary text-primary rounded-circle align-middle me-2"></i>
                                                Customer    </button>
                                        </li>
                                        <!-- Inspection tab -->
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link fs-15 p-3" id="pills-checking-tab"
                                                data-bs-toggle="pill" data-bs-target="#pills-checking" type="button"
                                                role="tab" aria-controls="pills-checking" aria-selected="false"
                                                data-position="3"><i
                                                    class="ri-checkbox-circle-line fs-16 p-2 bg-soft-primary text-primary rounded-circle align-middle me-2"></i>RTO
                                                Plan</button>
                                        </li>
                                        <!-- Agreement tab -->
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link fs-15 p-3" id="pills-agreement-tab"
                                                data-bs-toggle="pill" data-bs-target="#pills-agreement" type="button"
                                                role="tab" aria-controls="pills-agreement" aria-selected="false"
                                                data-position="5"><i
                                                    class="ri-checkbox-circle-line fs-16 p-2 bg-soft-primary text-primary rounded-circle align-middle me-2"></i>Agreement</button>
                                        </li>
                                        <!-- Payment Tab Start-->
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link fs-15 p-3" id="pills-payment-tab"
                                                data-bs-toggle="pill" data-bs-target="#pills-payment" type="button"
                                                role="tab" aria-controls="pills-payment" aria-selected="false"
                                                data-position="4"><i
                                                    class="ri-checkbox-circle-line fs-16 p-2 bg-soft-primary text-primary rounded-circle align-middle me-2"></i>Payment</button>
                                        </li>
                                        <!-- insurance -->
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link fs-15 p-3" id="pills-bill-customer-tab2"
                                                data-bs-toggle="pill" data-bs-target="#pills-bill-customer2"
                                                type="button" role="tab" aria-controls="pills-bill-customer2"
                                                aria-selected="false" data-position="2"><i
                                                    class="ri-checkbox-circle-line fs-16 p-2 bg-soft-primary text-primary rounded-circle align-middle me-2"></i>
                                                Insurance</button>
                                        </li>

                                        <!-- Conform -->
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link fs-15 p-3" id="pills-confirm-tab"
                                                data-bs-toggle="pill" data-bs-target="#pills-confirm" type="button"
                                                role="tab" aria-controls="pills-confirm" aria-selected="false"
                                                data-position="6"><i
                                                    class="ri-checkbox-circle-line fs-16 p-2 bg-soft-primary text-primary rounded-circle align-middle me-2"></i>Confirm</button>
                                        </li>
                                    </ul>
                                </div>
                                <div class="tab-content">

                                    <div class="tab-pane fade " id="pills-bill-customer2" role="tabpanel"
                                        aria-labelledby="pills-bill-customer-tab2">
                                        <!-- Accordian  Start-->

                                        <div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label for="pickupdate" class="form-label">Start
                                                        Date</label>
                                                    <input type="date" class="form-control" id="pickupdate">
                                                </div>
                                                <div class="col-md-4">
                                                    <label for="pickupdate" class="form-label">End
                                                        Date</label>
                                                    <input type="date" class="form-control" id="pickupdate">
                                                </div>
                                                <div class="col-md-4">
                                                    <label for="pickupdate" class="form-label">Upload
                                                        Insurance File</label>
                                                    <input type="file" class="form-control" id="pickupdate">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-end">
                                            <a href="#"><button class="btn btn-primary mt-4">Next</button></a>
                                        </div>
                                        <!-- Accordian End -->
                                    </div>

                                    <!-- customer tab pane start -->
                                    <div class="tab-pane fade " id="pills-bill-customer" role="tabpanel"
                                        aria-labelledby="pills-bill-customer-tab">
                                        <!-- Accordian  Start-->
                                        <div class="accordion" id="accordionPanelsStayOpenExample">
                                            <div class="accordion-item">
                                                <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                                                    <button class="accordion-button" type="button"
                                                        data-bs-toggle="collapse"
                                                        data-bs-target="#panelsStayOpen-collapseOne"
                                                        aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
                                                        Customer
                                                    </button>
                                                </h2>
                                                <div id="panelsStayOpen-collapseOne"
                                                    class="accordion-collapse collapse show"
                                                    aria-labelledby="panelsStayOpen-headingOne">
                                                    <div class="accordion-body">
                                                        <div class="row mb-4" style="align-items: center">
                                                            <div class="col-md-10">
                                                                <input list="browsers" name="browser" id="browser" class="form-control" placeholder="Search Customer">

                                                                <datalist id="browsers">
                                                                    <option value="Edge">
                                                                    </option><option value="Firefox">
                                                                    </option><option value="Chrome">
                                                                    </option><option value="Opera">
                                                                    </option><option value="Safari">
                                                                    </option></datalist>
                                                            </div>
                                                            <div class="col-md-2">
                                                                <a href="#">

                                                                    or Create New Customer
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <!-- form1 Start -->
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="card">
                                                                    <div class="card-body">
                                                                        <div class="live-preview">
                                                                            <div class="row gy-4">
                                                                                <div class="col-xxl-3 col-md-6">
                                                                                    <div>
                                                                                        <label for="firstName"
                                                                                            class="form-label">First
                                                                                            Name</label>
                                                                                        <input type="text"
                                                                                            class="form-control"
                                                                                            id="firstName">
                                                                                    </div>
                                                                                </div>
                                                                                <!--end col-->
                                                                                <div class="col-xxl-3 col-md-6">
                                                                                    <div>
                                                                                        <label for="lastName"
                                                                                            class="form-label">Last
                                                                                            Name</label>
                                                                                        <input type="text"
                                                                                            class="form-control"
                                                                                            id="lastName">
                                                                                    </div>
                                                                                </div>
                                                                                <!--end col-->
                                                                                <div class="col-xxl-3 col-md-6">
                                                                                    <div>
                                                                                        <label for="email"
                                                                                            class="form-label">Email</label>
                                                                                        <div class="form-icon">
                                                                                            <input type="email"
                                                                                                class="form-control form-control-icon"
                                                                                                id="email"
                                                                                                placeholder="example@gmail.com">
                                                                                            <i
                                                                                                class="ri-mail-unread-line"></i>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <!-- end col -->
                                                                                <div class="col-xxl-3 col-md-6">
                                                                                    <div>
                                                                                        <label for="phoneNumber"
                                                                                            class="form-label">Phone
                                                                                            Number</label>
                                                                                        <input type="text"
                                                                                            class="form-control"
                                                                                            id="phoneNumber">
                                                                                    </div>
                                                                                </div>
                                                                                <!--end col-->
                                                                                <div class="col-xxl-3 col-md-6">
                                                                                    <div>
                                                                                        <label for="street"
                                                                                            class="form-label">Street</label>
                                                                                        <input type="text"
                                                                                            class="form-control"
                                                                                            id="street">
                                                                                    </div>
                                                                                </div>
                                                                                <!--end col-->
                                                                                <div class="col-xxl-3 col-md-6">
                                                                                    <div>
                                                                                        <label for="street2"
                                                                                            class="form-label">Street
                                                                                            2</label>
                                                                                        <input type="text"
                                                                                            class="form-control"
                                                                                            id="street2">
                                                                                    </div>
                                                                                </div>
                                                                                <!--end col-->
                                                                                <div class="col-xxl-3 col-md-6">
                                                                                    <div>
                                                                                        <label for="city"
                                                                                            class="form-label">City</label>
                                                                                        <input type="text"
                                                                                            class="form-control"
                                                                                            id="city">
                                                                                    </div>
                                                                                </div>
                                                                                <!--end col-->
                                                                                <div class="col-xxl-3 col-md-6">
                                                                                    <div>
                                                                                        <label for="state"
                                                                                            class="form-label">State</label>
                                                                                        <input type="text"
                                                                                            class="form-control"
                                                                                            id="state">
                                                                                    </div>
                                                                                </div>
                                                                                <!--end col-->
                                                                                <div class="col-xxl-3 col-md-6">
                                                                                    <div>
                                                                                        <label for="zip"
                                                                                            class="form-label">Zip</label>
                                                                                        <input type="text"
                                                                                            class="form-control"
                                                                                            id="zip">
                                                                                    </div>
                                                                                </div>
                                                                                <!--end col-->
                                                                                <div class="col-xxl-3 col-md-6">
                                                                                    <div>
                                                                                        <label for="country"
                                                                                            class="form-label">Country</label>
                                                                                        <select id="inputState"
                                                                                            class="form-select"
                                                                                            data-choices=""
                                                                                            data-choices-sorting="true">
                                                                                            <option selected="">
                                                                                                Choose...
                                                                                            </option>
                                                                                            <option>Pakistan</option>
                                                                                            <option>Germany</option>
                                                                                            <option>United States
                                                                                            </option>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                                <!--end col-->
                                                                                <div class="col-xxl-3 col-md-6">
                                                                                    <div>
                                                                                        <label for="exampleInputdate"
                                                                                            class="form-label">Input
                                                                                            Date</label>
                                                                                        <input type="date"
                                                                                            class="form-control"
                                                                                            id="exampleInputdate">
                                                                                    </div>
                                                                                </div>
                                                                                <!--end col-->
                                                                            </div>
                                                                            <!--end row-->
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--end col-->
                                                        </div> <!-- form1 end -->
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="d-flex justify-content-end">
                                            <a href="#"><button class="btn btn-primary mt-4">Next</button></a>
                                        </div>
                                        <!-- Accordian End -->
                                    </div>

                                    <!--                                    </div>-->
                                    <!-- dates tab pane end-->
                                    <!-- cars tab pane start -->
                                    <div class="tab-pane fade active show" id="pills-cars" role="tabpanel"
                                        aria-labelledby="pills-cars-tab">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <!-- Search box & heading -->
                                                        <div class="row" style="align-items: center">
                                                            <div class="col-md-10">
                                                                <input list="browsers" name="browser" id="browser"
                                                                    class="form-control" placeholder="Search Vehicle">

                                                                <datalist id="browsers">
                                                                    <option value="Edge">
                                                                    <option value="Firefox">
                                                                    <option value="Chrome">
                                                                    <option value="Opera">
                                                                    <option value="Safari">
                                                                </datalist>
                                                            </div>
                                                            <div class="col-md-2">
                                                                <a href="#">

                                                                    or Create New Vehicle
                                                                </a>
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <div class="card-body">

                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <div class="card card-cars">

                                                                    <div class="car">
                                                                        <img class="rounded-start img-fluid"
                                                                            href="{{url('assets')}}/images/toyota-img1.png"
                                                                            alt="Card image" />
                                                                    </div>
                                                                    <div class="car-body">
                                                                        <div class="card-header">
                                                                            <h5 class="card-title mb-0">
                                                                                Toyota Corolla or similar
                                                                            </h5>
                                                                        </div>
                                                                        <div class="card-body">
                                                                            <p class="card-text">
                                                                                Compact
                                                                            </p>
                                                                            <h6 class="card-text mb-2">
                                                                                Starting From
                                                                            </h6>
                                                                            <p class="card-text">
                                                                                $75.00
                                                                            </p>
                                                                            <button type="button"
                                                                                class="btn btn-primary"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#exampleModal">
                                                                                Add To RTO
                                                                            </button>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="card card-cars">

                                                                    <div class="car">
                                                                        <img class="rounded-start img-fluid"
                                                                            href="{{url('assets')}}/images/cerato.png"
                                                                            alt="Card image" />
                                                                    </div>
                                                                    <div class="car-body">
                                                                        <div class="card-header">
                                                                            <h5 class="card-title mb-0">
                                                                                Kia Cerato Hatch or similar
                                                                            </h5>
                                                                        </div>
                                                                        <div class="card-body">
                                                                            <p class="card-text">
                                                                                Intermediate
                                                                            </p>
                                                                            <h6 class="card-text mb-2">
                                                                                Starting From
                                                                            </h6>
                                                                            <p class="card-text">
                                                                                $85.00
                                                                            </p>
                                                                            <button type="button"
                                                                                class="btn btn-primary"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#exampleModal">
                                                                                Add To RTO
                                                                            </button>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="card card-cars">

                                                                    <div class="car">
                                                                        <img class="rounded-start img-fluid"
                                                                            href="{{url('assets')}}/images/mitsubishi-img1.png"
                                                                            alt="Card image" />
                                                                    </div>
                                                                    <div class="car-body">
                                                                        <div class="card-header">
                                                                            <h5 class="card-title mb-0">
                                                                                Mitsubishi Mirage or similar
                                                                            </h5>
                                                                        </div>
                                                                        <div class="card-body">
                                                                            <p class="card-text">
                                                                                Mini
                                                                            </p>
                                                                            <h6 class="card-text mb-2">
                                                                                Starting From
                                                                            </h6>
                                                                            <p class="card-text">
                                                                                $65.00
                                                                            </p>
                                                                            <button type="button"
                                                                                class="btn btn-primary"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#exampleModal">
                                                                                Add To RTO
                                                                            </button>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Item 1 -->

                                                        <!-- Modal -->
                                                        <div class="modal fade" id="exampleModal" tabindex="-1"
                                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalLabel">
                                                                            Options</h5>
                                                                        <button type="button" class="btn-close"
                                                                            data-bs-dismiss="modal"
                                                                            aria-label="Close"></button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <!-- Option 1 -->
                                                                        <div class="card">
                                                                            <div class="card-body">
                                                                                <div
                                                                                    class="d-flex justify-content-between">
                                                                                    <div>
                                                                                        <h4>BASIC COVER INCLUDED</h4>
                                                                                        <p>If you have an accident or
                                                                                            damage
                                                                                            the
                                                                                            vehicle, your excess
                                                                                            liability
                                                                                            is
                                                                                            $4,818.</p>
                                                                                    </div>
                                                                                    <span>
                                                                                        <a href="#"><i
                                                                                                class=" las la-edit"></i></a>
                                                                                        $0.00 x
                                                                                        <input type="number"
                                                                                            id="quantity"
                                                                                            name="quantity" min="1"
                                                                                            max="5">
                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <!-- option 2 -->
                                                                        <div class="card">
                                                                            <div class="card-body">
                                                                                <div
                                                                                    class="d-flex justify-content-between">

                                                                                    <div>
                                                                                        <h4>Silver Cover</h4>
                                                                                        <p>This allows you to reduce the
                                                                                            excess liability to $1800.
                                                                                            Includes Roadside Assistance
                                                                                        </p>
                                                                                    </div>
                                                                                    <div>
                                                                                        <a href="#"><i
                                                                                                class=" las la-edit"></i></a>
                                                                                        $ 270.00 x
                                                                                        <input type="checkbox">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <!-- option 3 -->
                                                                        <div class="card">
                                                                            <div class="card-body">
                                                                                <div
                                                                                    class="d-flex justify-content-between">

                                                                                    <div>
                                                                                        <h4>Gold Cover</h4>
                                                                                        <p>This allows you to reduce the
                                                                                            excess liability to $0.
                                                                                            Includes Roadside Assistance
                                                                                        </p>
                                                                                    </div>
                                                                                    <div>
                                                                                        <a href="#"><i
                                                                                                class=" las la-edit"></i></a>
                                                                                        $ 450.00 x
                                                                                        <input type="checkbox">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <!-- option 4 -->
                                                                        <div class="card">
                                                                            <div class="card-body">
                                                                                <div
                                                                                    class="d-flex justify-content-between">

                                                                                    <div>
                                                                                        <h4>Drivers Under 25 and Over 75
                                                                                            Years</h4>
                                                                                        <p>You MUST select this option
                                                                                            if you are under 25 or Over
                                                                                            75 years Old. Excess For
                                                                                            Drivers <br> under 25 and
                                                                                            Over 75
                                                                                            is $5000.</p>
                                                                                    </div>

                                                                                    <div>
                                                                                        <a href="#"><i
                                                                                                class=" las la-edit"></i></a>
                                                                                        $ 75.00 x <input
                                                                                            type="checkbox">
                                                                                    </div>


                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <!-- option 5 -->
                                                                        <div class="card">
                                                                            <div class="card-body">
                                                                                <div
                                                                                    class="d-flex justify-content-between">

                                                                                    <div>
                                                                                        <h4>Additional Driver</h4>
                                                                                        <p>Use this option if there is
                                                                                            more then 1 Driver.</p>
                                                                                    </div>
                                                                                    <div>
                                                                                        <a href="#"><i
                                                                                                class=" las la-edit"></i></a>
                                                                                        $ 30.00 x
                                                                                        <input type="number"
                                                                                            id="quantity"
                                                                                            name="quantity" min="1"
                                                                                            max="5">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <!-- option 6 -->
                                                                        <div class="card">
                                                                            <div class="card-body">
                                                                                <div
                                                                                    class="d-flex justify-content-between">

                                                                                    <div>
                                                                                        <h4>Child Seat</h4>
                                                                                        <p>For Children between 0-4
                                                                                            Years
                                                                                        </p>
                                                                                    </div>
                                                                                    <div>
                                                                                        <a href="#"><i
                                                                                                class=" las la-edit"></i></a>
                                                                                        $ 30.00 x
                                                                                        <input type="number"
                                                                                            id="quantity"
                                                                                            name="quantity" min="1"
                                                                                            max="5">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <!-- option 7 -->
                                                                        <div class="card">
                                                                            <div class="card-body">
                                                                                <div
                                                                                    class="d-flex justify-content-between">

                                                                                    <div>
                                                                                        <h4>Booster Seat</h4>
                                                                                        <p>For Children between 4-8
                                                                                            Years</p>
                                                                                    </div>
                                                                                    <div>
                                                                                        <a href="#"><i
                                                                                                class=" las la-edit"></i></a>
                                                                                        $ 30.00 x
                                                                                        <input type="number"
                                                                                            id="quantity"
                                                                                            name="quantity" min="1"
                                                                                            max="5">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>


                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-bs-dismiss="modal">Close</button>
                                                                        <button type="button"
                                                                            class="btn btn-primary">Add</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Item 2 -->

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- cars tab pane end -->
                                    <!-- Payment tab pane start -->
                                    <div class="tab-pane fade" id="pills-payment" role="tabpanel"
                                        aria-labelledby="pills-payment-tab">
                                        <div>
                                            <h5 class="mb-1">Payment Selection</h5>
                                            <p class="text-muted mb-4">Please select and enter your billing information
                                            </p>
                                        </div>

                                        <div class="row g-4">

                                            <div class="col-lg-6 col-sm-6">
                                                <div data-bs-toggle="collapse" data-bs-target="#paymentmethodCollapse"
                                                    aria-expanded="true" aria-controls="paymentmethodCollapse">
                                                    <div class="form-check card-radio">
                                                        <input id="paymentMethod02" name="paymentMethod" type="radio"
                                                            class="form-check-input" checked="">
                                                        <label class="form-check-label" for="paymentMethod02">
                                                            <span class="fs-16 text-muted me-2"><i
                                                                    class="ri-bank-card-fill align-bottom"></i></span>
                                                            <span class="fs-15 text-wrap">Credit / Debit Card</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-lg-6 col-sm-6">
                                                <div data-bs-toggle="collapse"
                                                    data-bs-target="#paymentmethodCollapse.show" aria-expanded="false"
                                                    aria-controls="paymentmethodCollapse">
                                                    <div class="form-check card-radio">
                                                        <input id="paymentMethod03" name="paymentMethod" type="radio"
                                                            class="form-check-input">
                                                        <label class="form-check-label" for="paymentMethod03">
                                                            <span class="fs-16 text-muted me-2"><i
                                                                    class="ri-money-dollar-box-fill align-bottom"></i></span>
                                                            <span class="fs-15 text-wrap">Cash In Store</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="collapse show" id="paymentmethodCollapse">
                                            <div class="card p-4 border shadow-none mb-0 mt-4">
                                                <div class="row gy-3">
                                                    <div class="col-md-12">
                                                        <label for="cc-name" class="form-label">Name on card</label>
                                                        <input type="text" class="form-control" id="cc-name"
                                                            placeholder="Enter name">
                                                        <small class="text-muted">Full name as displayed on card</small>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label for="cc-number" class="form-label">Credit card
                                                            number</label>
                                                        <input type="text" class="form-control" id="cc-number"
                                                            placeholder="xxxx xxxx xxxx xxxx">
                                                    </div>

                                                    <div class="col-md-3">
                                                        <label for="cc-expiration" class="form-label">Expiration</label>
                                                        <input type="text" class="form-control" id="cc-expiration"
                                                            placeholder="MM/YY">
                                                    </div>

                                                    <div class="col-md-3">
                                                        <label for="cc-cvv" class="form-label">CVV</label>
                                                        <input type="text" class="form-control" id="cc-cvv"
                                                            placeholder="xxx">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="text-muted mt-2 fst-italic">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                    viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                    class="feather feather-lock text-muted icon-xs">
                                                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                                    <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                                                </svg> Your transaction is secured with SSL encryption
                                            </div>
                                        </div>

                                        <div class="d-flex justify-content-end gap-3 mt-4">
                                            <!-- <button type="button" class="btn btn-light btn-label previestab"
                                                data-previous="pills-bill-dates-tab"><i
                                                    class="ri-arrow-left-line label-icon align-middle fs-16 me-2"></i>Back
                                                to Shipping</button>
                                            <button type="button"
                                                class="btn btn-primary btn-label right ms-auto @include('admin.header')"
                                                data-nexttab="pills-payment-tab"><i
                                                    class="ri-shopping-basket-line label-icon align-middle fs-16 ms-2"></i>Complete
                                                Order</button> -->
                                            <button type="button" class="btn btn-primary">Charge Card</button>

                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                data-bs-target="#staticBackdrop">View
                                                Invoice</button>

                                            <!-- Modal -->
                                            <div class="modal fade " id="staticBackdrop" data-bs-backdrop="static"
                                                data-bs-keyboard="false" tabindex="-1"
                                                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-lg card">
                                                    <div class="modal-content">
                                                        <div class="modal-header card-header">
                                                            <h3 class="modal-title" id="staticBackdropLabel">Invoice
                                                            </h3>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body card-body">
                                                            <div>
                                                                <div>
                                                                    <div class="row invo-header">
                                                                        <div class="col-sm-6">
                                                                            <div class="media">
                                                                                <div class="media-left">
                                                                                    <!-- <a href="#"><img
                                                                                            class="media-object img-60"
                                                                                            src="../assets/images/logo/logo-1.png"
                                                                                            alt=""></a> -->
                                                                                </div>
                                                                                <div class="media-body m-l-20">
                                                                                    <h4 class="media-heading f-w-600">
                                                                                        Walter White</h4>
                                                                                    <p>
                                                                                        walterWhite@gmail.com<br>
                                                                                        <span class="digits">Sydney
                                                                                            Branch</span>
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                            <!-- End Info-->
                                                                        </div>
                                                                        <div class="col-sm-6">
                                                                            <div class="text-md-end text-xs-center">
                                                                                <h3>Invoice #<span
                                                                                        class="digits counter">0420</span>
                                                                                </h3>
                                                                                <p>
                                                                                    Issued: May<span class="digits"> 27,
                                                                                        2022</span><br>
                                                                                    Payment Due: June <span
                                                                                        class="digits">27, 2021</span>
                                                                                </p>
                                                                            </div>
                                                                            <!-- End Title                                 -->
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!-- End InvoiceTop-->

                                                                <!-- End Invoice Mid-->
                                                                <div>
                                                                    <div class="table-responsive invoice-table"
                                                                        id="table">
                                                                        <table
                                                                            class="table table-bordered table-striped">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td>
                                                                                        <h6 class="p-2 mb-0">Car
                                                                                            Description</h6>
                                                                                    </td>

                                                                                    <td>
                                                                                        <h6 class="p-2 mb-0">Rate
                                                                                        </h6>
                                                                                    </td>
                                                                                </tr>

                                                                                <tr>
                                                                                    <td>
                                                                                        <label>Car Name</label>
                                                                                        <p class="m-0">Lorem Ipsum is
                                                                                            simply dummy text of the
                                                                                            printing and typesetting
                                                                                            industry.</p>
                                                                                    </td>


                                                                                    <td>
                                                                                        <p>
                                                                                            AU$500.00</p>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>
                                                                                        <label>Car Name</label>
                                                                                        <p class="m-0">Lorem Ipsum is
                                                                                            simply dummy text of the
                                                                                            printing and typesetting
                                                                                            industry.</p>
                                                                                    </td>

                                                                                    <td>
                                                                                        <p>
                                                                                            AU$500.00</p>
                                                                                    </td>
                                                                                </tr>

                                                                                <tr>

                                                                                    <td>
                                                                                        <h6 class="mb-0 p-2">Grand Total
                                                                                        </h6>
                                                                                    </td>
                                                                                    <td>
                                                                                        <h6 class="mb-0 p-2">AU$1,000.00
                                                                                        </h6>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </div>
                                                                    <!-- End Table-->

                                                                </div>
                                                                <!-- End InvoiceBot-->
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer card-footer">
                                                            <button type="button" class="btn btn-primary">Print</button>
                                                            <button type="button" class="btn btn-primary">Send
                                                                Email</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Payment tab end -->

                                    <!-- Agreement tab start -->
                                    <div class="tab-pane fade" id="pills-agreement" role="tabpanel"
                                        aria-labelledby="pills-agreement-tab">
                                        <div class="card license-card">
                                            <div class="card-header">
                                                <div class="d-flex justify-content-between header-aggrement-main-div">
                                                    <div class="img-agreement">
                                                        <img src="{{url('assets')}}/images/Simba_Final_webPNG.png" alt=""
                                                            height="60">
                                                    </div>
                                                    <div>

                                                        <h4>CAR SALE CONTRACT</h4>
                                                    </div>
                                                    <div class="agrement-header">
                                                        <h5 class="m-0">SIMBA CAR HIRE PTY LTD</h5>
                                                        <br>

                                                        <!-- <p class="m-0">AR HIRE PTY LTD
                                                            ABN: 87635707229</p> -->
                                                        <p class="m-0">Office 4/937 Marion Road<br>Mitchell Park, South
                                                            Australia 5043 <br> Australia</p>
                                                        <br>
                                                        <p class="m-0">PHONE: 08 8312 4616 / MOBILE: 0459 434 800</p>
                                                        <a href="admin@simbacarhire.com.au ">EMAIL:
                                                            admin@simbacarhire.com.au </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <div>
                                                    <ol>
                                                        <li>This form states the terms and conditions of sale of the
                                                            below
                                                            mentioned vehicle</li>
                                                        <br>
                                                        <li>The buyer is advised to take pictures of the seller’s
                                                            vehicle as
                                                            a proof of condition at the time of collection. The buyer
                                                            waives any cooling off period.
                                                        </li>
                                                        <br>
                                                        <li>Legal title of the vehicle will pass to the buyer only once
                                                            full
                                                            payment is made</li>
                                                    </ol>
                                                    <p>Date:______</p>
                                                </div>
                                                <div>
                                                    <h6>BUYER DETAILS</h6>
                                                    <ul class="list-unstyled">
                                                        <li>Name:</li>
                                                        <li>Address: </li>
                                                        <li>Email Address:</li>
                                                        <li>Licence Number:</li>
                                                        <li>Licence Expiry:</li>
                                                        <li>Date of Birth:</li>
                                                        <li>Contact Number:</li>
                                                        <li>Reference:</li>
                                                    </ul>
                                                </div>
                                                <div>
                                                    <h6>SELLER DETAILS</h6>
                                                    <p>Name: Simba Car Hire Pty Ltd</p>
                                                    <p>Address: U4/937 MARION ROAD, MITCHELL PARK SA 5043
                                                    </p>
                                                </div>
                                                <div>
                                                    <h6>DETAILS OF VEHICLE</h6>
                                                    <table class="table">
                                                        <tbody>
                                                            <tr>
                                                                <td>Make / Model</td>
                                                                <td>Toyota Camry</td>
                                                                <td>Year of Manufacture</td>
                                                                <td>22/02/2019</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Engine No </td>
                                                                <td>00325489711</td>
                                                                <td>Colour</td>
                                                                <td>Black</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Vin No</td>
                                                                <td>125486</td>
                                                                <td>Last Mileage
                                                                </td>
                                                                <td>11</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Registration Number</td>
                                                                <td>10001</td>
                                                                <td>Registration Expiry</td>
                                                                <td>22/02/2024</td>
                                                            </tr>
                                                        </tbody>


                                                    </table>
                                                </div>
                                                <div>
                                                    <h6>Additional Notes</h6>
                                                    <textarea name="notes" id="notes" cols="30" rows="10"
                                                        class="form-control" placeholder="Notes.."></textarea>
                                                </div>
                                                <div class="d-flex justify-content-between mt-5">
                                                    <p>Buyer's Name:__________________</p>
                                                    <p>Buyer's Signature:____________________</p>
                                                </div>
                                                <div>
                                                    <p>I, ________________________________________, hereby agree to buy
                                                        from the seller (Simba Car Hire Pty Ltd). The
                                                        above-mentioned vehicle in its current condition for the sum of
                                                        $ ____________.
                                                    </p>
                                                    <p>In addition to this contract the seller and the buyer go into an
                                                        agreement whereby the buyer will pay the purchase price of
                                                        the vehicle in instalments. Details of this agreement are stated
                                                        below. </p>
                                                </div>
                                                <div>
                                                    <table class="table">
                                                        <tr class="text-start">
                                                            <td>Purchase Price Including GST
                                                            </td>
                                                            <td>$2000</td>
                                                        </tr>
                                                        <tr class="text-start">
                                                            <td>Less deposit (Non-refundable Item)
                                                            </td>
                                                            <td>seat</td>
                                                        </tr>
                                                        <tr class="text-start">
                                                            <td>Balance Remaining
                                                            </td>
                                                            <td>$200</td>
                                                        </tr>
                                                        <tr class="text-start">
                                                            <td>Add Fees and charges (REGO, FUEL, MISC) ( Non-refundable
                                                                item)
                                                            </td>
                                                            <td>$300</td>
                                                        </tr>
                                                        <tr class="text-start">
                                                            <td>Total Amount
                                                            </td>
                                                            <td>$70000</td>
                                                        </tr>
                                                        <tr class="text-start">
                                                            <td>Amount per week</td>
                                                            <td>$400</td>
                                                        </tr>
                                                        <tr class="text-start">
                                                            <td>A. Maintenance cost per week (refundable item)
                                                            </td>
                                                            <td>$350</td>
                                                        </tr>
                                                        <tr class="text-start">
                                                            <td>B. Insurance Cost per week (refundable item)
                                                            </td>
                                                            <td>$200</td>
                                                        </tr>
                                                        <tr class="text-start">
                                                            <td>C. Registration Cost per week (refundable item)</td>
                                                            <td>$100</td>
                                                        </tr>
                                                        <tr class="text-start">
                                                            <td>Interest if applicable. 1 year 2 year 3 year</td>
                                                            <td>$80</td>
                                                        </tr>
                                                        <tr class="text-start">
                                                            <td>Total Amount</td>
                                                            <td>$85000</td>
                                                        </tr>
                                                        <tr class="text-start">
                                                            <td>Total amount per week inc GST
                                                            </td>
                                                            <td>$400</td>
                                                        </tr>
                                                        <tr class="text-start">
                                                            <td>Total amount including 1.5% direct debit fee inc GST
                                                            </td>
                                                            <td>$40</td>
                                                        </tr>
                                                        <tr class="text-start">
                                                            <td>Balloon Payment at the end of ______ weeks
                                                            </td>
                                                            <td>$480</td>
                                                        </tr>
                                                    </table>
                                                </div>
                                                <div>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            Uber inspection per year subject to change:
                                                        </div>
                                                        <div class="col-md-8">$103 (RAA) $85 (RIGHTWAY)
                                                        </div>
                                                        <div class="col-md-4">
                                                            Rideshare Fees:
                                                        </div>
                                                        <div class="col-md-8">As per Rideshare fees
                                                        </div>
                                                        <div class="col-md-4">
                                                            Rideshare Registration Upgrade:
                                                        </div>
                                                        <div class="col-md-8">As per government fees

                                                        </div>
                                                        <div class="col-md-4">
                                                            Administration cost when due:
                                                        </div>
                                                        <div class="col-md-8">$110 inc GST (Anytime when Simba Car hire
                                                            representative
                                                            is required to undertake any administration request)

                                                        </div>
                                                        <div class="col-md-4">
                                                            Internal mechanic inspection:
                                                        </div>
                                                        <div class="col-md-8">$85 inc GST
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="d-flex justify-content-between mt-5">
                                                    <p>Buyer's Name:__________________</p>
                                                    <p>Buyer's Signature:____________________</p>
                                                </div>
                                                <div>
                                                    <h6 class="text-center">TERMS AND CONDITIONS OF THE INSTALMENT
                                                        AGREEMENT</h6>
                                                    <ol>
                                                        <li>Buyer can pay out the vehicle price at any stage during the
                                                            _____ weeks.</li>
                                                        <li>This agreement is interest free / interest applicable and
                                                            should not be taken as finance agreement. Simba Car hire
                                                            agrees that if the buyer wants to pay out the vehicle before
                                                            the end of the settlement date, the buyer will only incur
                                                            interest charges for the nearest 1 year as outlined in the
                                                            purchase price table.</li>
                                                        <li>Terms of Settlement is ______ weeks.</li>
                                                        <li>Buyer authorises Simba Car Hire to direct debit the weekly
                                                            amount plus 1.5% direct debit fee (Using Gocardless
                                                            company to direct debit) from the nominated bank account
                                                            details herewith for ________ weeks.<br>
                                                            <table class="table">
                                                                <tr>
                                                                    <td>Name of Bank:</td>
                                                                    <td>Account Holder Name:</td>

                                                                </tr>
                                                                <tr>
                                                                    <td>BSB: </td>
                                                                    <td>Account Number:
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Card Number:</td>
                                                                    <td>Exp: </td>
                                                                    <td>CVN:</td>
                                                                </tr>
                                                            </table>
                                                        </li>
                                                        <li>All Expenses are paid by the buyer such as Registration,
                                                            Maintenance, and Insurance. $20 Admin Fee for fines and
                                                            toll. Alternatively, the buyer will pay _______________ and
                                                            ________________ and _______________.</li>
                                                        <li>Simba car hire is the legal owner of the vehicle prescribed
                                                            in this agreement. Title shall be released once full payment
                                                            has been received. At the completion of this agreement Simba
                                                            Car Hire will issue the registration certificate to the
                                                            buyer</li>
                                                        <li>Buyer will need to pay the stamp duty to transfer vehicle
                                                            ownership into the buyer’s name at the completion of this
                                                            agreement.</li>
                                                        <li> In the event of Total Loss of the vehicle Simba Car Hire
                                                            Will refund a minimum amount of $ ________________ and
                                                            the maximum amount to be the payout amount less the balance
                                                            of the purchase price of the vehicle. Or Replacement
                                                            of Old car with new car (Like for like) subject to insurance
                                                            decision.</li>
                                                        <li>_____ week in advance paid and the first direct debit to
                                                            start on _____________________
                                                        </li>
                                                        <li> Start Date: ____________________ End Date:
                                                            _____________________
                                                        </li>
                                                        <li>Insurance excess is: $
                                                        </li>
                                                        <li>Insurance is subject to change. In the event of an accident
                                                            the insurance maybe be increased.</li>
                                                        <li> As stated in the purchase price table, the deposit and all
                                                            charges incurred is strictly non-refundable and as we are
                                                            entering into this contract on the basis that the buyer is
                                                            committing to buying the vehicle under instalment therefore
                                                            the buyer agrees to any cooling off period to be waived</li>
                                                        <li>At the end of the agreement, the buyer will receive the
                                                            spare car keys and signed registration papers for the buyer
                                                            to
                                                            transfer under their name.</li>
                                                        <li>In the instance where there are 3 failed payments
                                                            consecutively Simba Car Hire PTY LTD reserves the right to
                                                            recover the vehicle. We also reserve the right to report the
                                                            vehicle to the police and appoint debt collectors to recover
                                                            the vehicle. Recovery Cost will include recovery fee and
                                                            interest of 2%.</li>
                                                        <li>This agreement is bound by consumer rights which protects
                                                            both the buyer and the seller.</li>
                                                        <li>The Corporations Act 2001 determines the order in which the
                                                            external administrator has to repay money owed by a
                                                            company to certain creditors. Consumers will generally be
                                                            ordinary unsecured creditors and will only be paid after
                                                            monies owing to other classes of creditors, such as
                                                            employees and shareholders, have been repaid.</li>
                                                        <li>Simba Car hire does not represent any rideshare platforms.
                                                        </li>
                                                        <li>Simba Car hire is not responsible for any changes made by
                                                            the rideshare platforms in relation to vehicles or any such
                                                            matters arising during the installment period.</li>
                                                        <li>If the buyer is not able to complete and or pay the minimum
                                                            cost during the installment period, Simba Car hire will
                                                            demand return of the vehicle and all payments made by the
                                                            buyer including any deposit will be treated as a rental fee
                                                            and there will be no refunds whatsoever for payments made.
                                                        </li>
                                                        <li>Despite our ownership in the vehicle, the buyer bears the
                                                            entire risk of loss arising in connection with the
                                                            possession,
                                                            use, storage, maintenance, seizure and repair of the
                                                            Vehicle. (This includes loss arising because of theft,
                                                            destruction,
                                                            or damage and loss arising out of claims of injury.)</li>
                                                        <li>The buyer must not change the place where the vehicle is
                                                            housed without the seller’s prior written consent, which
                                                            will
                                                            not be unreasonably withheld.</li>
                                                        <li>The buyer must use the vehicle for the purpose for which it
                                                            is designed. The buyer must ensure that the vehicle is
                                                            used in accordance with the supplier’s and manufacturer’s
                                                            instructions and recommendations, in compliance with all
                                                            laws that apply to the Vehicle or its use.</li>
                                                        <li>The buyer must take proper care of the vehicle and keep it
                                                            in good working order and good repair.</li>
                                                        <li>The buyer must ensure that the vehicle is maintained in
                                                            accordance with the supplier’s specifications and our or any
                                                            insurer’s reasonable requirements. The buyer must do all
                                                            things to maintain the supplier’s and manufacturer’s
                                                            warranties</li>
                                                        <li>The buyer must keep all maintenance records and all other
                                                            records relating to the inspection, commissioning or
                                                            alteration of the vehicle and make those records available
                                                            upon request.</li>
                                                        <li>The buyer must not withhold any payment under this
                                                            agreement, or make any deduction from it for any reason
                                                            including, because: <ul class="list-unstyled">
                                                                <li>(a) The vehicle is damaged, does not operate
                                                                    efficiently or at all, does not confirm to
                                                                    specifications or is not in the
                                                                    buyer’s possession; or </li>
                                                                <li>(b) The buyer claims to have a set-off,
                                                                    counterclaim, or other right against the seller or
                                                                    any other person.</li>
                                                            </ul>
                                                        </li>
                                                        <li>The buyer indemnifies the seller against any loss or
                                                            liability arising from and any reasonable costs (including
                                                            on
                                                            account of funds borrowed, contracted for or used to fund
                                                            any amount payable by the seller in connection with the
                                                            seller’s purchase of the vehicle or this agreement and legal
                                                            fees and expenses) reasonably incurred in connection with:
                                                            <ul class="list-unstyled">
                                                                <li>(c) Simba Car hire exercising a right under this
                                                                    agreement; or</li>
                                                                <li>(d) Simba Car hire doing anything the buyer should
                                                                    have done under the agreement; or</li>
                                                                <li>(e) The buyer not doing what the buyer should have
                                                                    done under the agreement; or</li>
                                                                <li>(f) Simba Car hire having to seize or store the
                                                                    Vehicle; or</li>
                                                                <li>(g) A person being injured or killed, or property
                                                                    being damaged directly or indirectly by the vehicle
                                                                    or its use; or</li>
                                                                <li>Any proceedings or prosecutions commenced against
                                                                    Simba Car hire or any fine or penalty imposed on
                                                                    Simba
                                                                    Car hire under occupational health and safety
                                                                    legislation in relation to the vehicle or its use.
                                                                </li>
                                                            </ul>
                                                        </li>
                                                    </ol>
                                                </div>
                                                <div class="d-flex justify-content-between mt-5">
                                                    <p>Buyer's Name:__________________</p>
                                                    <p>Buyer's Signature:____________________</p>
                                                </div>
                                                <div>
                                                    <h4 class="text-center">MANDATORY INSURANCE QUESTIONS</h4>
                                                    <h5>Please answer the following insurance related questions with YES
                                                        or NO. If any of your
                                                        answers are YES, please give explanation and details.</h5>
                                                    <p> 1. In the last 3 years has the main driver had any car related
                                                        claims, driver license suspensions, cancellations,
                                                        disqualifications, or restrictions? ________
                                                    </p>
                                                    <p> 2. In the last 3 years, have you or anyone to be insured under
                                                        this policy had an insurance policy declined or
                                                        cancelled, a renewal declined, special terms imposed, or had a
                                                        claim refused? ________
                                                    </p>
                                                    <p> 3. In the last 3 years, have you or anyone to be insured under
                                                        this policy committed any criminal act in
                                                        relation to fraud, theft, burglary, drugs, arson, criminal
                                                        damage, malicious damage, or willful damage?
                                                        ________</p>
                                                    <p>I, ________________________________________ hereby affirm that I
                                                        have answered the above questions
                                                        truthfully.</p>
                                                </div>
                                                <div class="d-flex justify-content-between mt-4">
                                                    <div>
                                                        <p>Insured’s Signature: _________________________________ </p>
                                                    </div>
                                                    <div>
                                                        <p>Date: ____________________</p>
                                                    </div>
                                                </div>

                                                <div class="text-center">
                                                    <h6>SIMBA CAR HIRE PTY LTD</h6>
                                                    <p class="m-0">Office 4/937 Marion Road, Mitchell Park, South
                                                        Australia 5043
                                                        Australia
                                                    </p>
                                                    <div class="d-flex justify-content-center">
                                                        <div style="margin-left:6px;">
                                                            <p class="m-0">PH 08 8312 4616</p>
                                                        </div>
                                                        <div style="margin-left:6px;">
                                                            <a href="admin@simbacarhire.com.au"><span
                                                                    style="color:black;">E</span>
                                                                admin@simbacarhire.com.au</a>
                                                        </div>
                                                        <div style="margin-left:6px;">
                                                            <p class="m-0">ABN 87635707229</p>
                                                        </div>
                                                    </div>
                                                    <p><a href="www.simbacarhire.com.au">www.simbacarhire.com.au</a></p>
                                                </div>

                                            </div>
                                            <div class="card-footer d-flex justify-content-between align-items-center">
                                                <div>
                                                    <input type="checkbox" id="licenseCheck">
                                                    <label for="licenseCheck">Agree with all terms & conditions</label>
                                                </div>
                                                <div>
                                                    <button type="button" class="btn btn-primary"
                                                        disabled>Email</button>
                                                    <button type="button" class="btn btn-primary"
                                                        disabled>Print</button>
                                                    <button type="button" class="btn btn-primary" disabled>Next</button>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- Agreement tab end -->
                                    <!-- RTO PLAN tab start -->
                                    <div class="tab-pane fade" id="pills-checking" role="tabpanel"
                                        aria-labelledby="pills-checking-tab">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h4 class="card-title">RTO Installment Plan</h4>
                                                    </div>
                                                    <div class="card-body" style="padding: 2rem;">
                                                        <div class="d-flex justify-content-between">
                                                            <p>Name</p>
                                                            <p></p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Served By</p>
                                                            <p></p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Vehicle</p>
                                                            <p></p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Purchase Price</p>
                                                            <input type="text">
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Less Deposit</p>
                                                            <input type="text">
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Balance</p>
                                                            <p>0</p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>RideShare & DPTI Fees
                                                            </p>
                                                            <input type="text">
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Miscellenous Fees</p>
                                                            <input type="text">
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Final Balance</p>
                                                            <p>0</p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Interest Year 1</p>
                                                            <p>0</p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Interest Year 2</p>
                                                            <p>0</p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Interest Year 3</p>
                                                            <p>0</p>
                                                        </div>

                                                        <div class="d-flex justify-content-between">
                                                            <p>Weekly Amount For 1 Year</p>
                                                            <p>0.00</p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Weekly Amount For 2 Year</p>
                                                            <p>0.00</p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Weekly Amount For 3 Year</p>
                                                            <p>0.00</p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Insurance Per Week</p>
                                                            <input type="text">
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Excess Drivers Over 25 is $950</p>
                                                            <input type="text">
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Excess Drivers Over 25 is $1350</p>
                                                            <input type="text">
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Unlisted Driver Additional $1400</p>
                                                            <input type="text">
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Unlisted Driver Under 25 Additional $2000</p>
                                                            <input type="text">
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Weekly Amount With Insurance For 1 Year</p>
                                                            <p>0.00</p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Weekly Amount With Insurance 2 Year</p>
                                                            <p>0.00</p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>Weekly Amount With Insurance For 3 Year</p>
                                                            <p>0.00</p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>WEEKLY AMOUNT DIRECT DEBT FEE 1.5% 1 YEAR</p>
                                                            <p>0.00</p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>WEEKLY AMOUNT DIRECT DEBT FEE 1.5% 2 YEAR</p>
                                                            <p>0.00</p>
                                                        </div>
                                                        <div class="d-flex justify-content-between">
                                                            <p>WEEKLY AMOUNT DIRECT DEBT FEE 1.5% 3 YEAR</p>
                                                            <p>0.00</p>
                                                        </div>
                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Fornightly</th>
                                                                    <th>Monthly</th>

                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>0.00</td>
                                                                    <td>0.00</td>
                                                                    <td>1 year</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>0.00</td>
                                                                    <td>0.00</td>
                                                                    <td>2 year</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>0.00</td>
                                                                    <td>0.00</td>
                                                                    <td>3 year</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <!-- checking tab end -->
                                    <!-- Summary tab pane start -->
                                    <div class="tab-pane fade" id="pills-confirm" role="tabpanel"
                                        aria-labelledby="pills-confirm-tab">
                                        <div class="card">
                                            <div class="card-header">
                                                <h4 class="card-title">Summary</h4>
                                            </div>
                                            <div class="card ribbon-box border shadow-none mb-lg-0">
                                                <div class="card-body">
                                                    <div class="ribbon ribbon-primary round-shape">Customer Info</div>


                                                    <div class="ribbon-content mt-4 text-muted">
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <label for="name">Customer Name: </label>
                                                                <p>Walter White</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="email">Customer Email: </label>
                                                                <p>walterWhite@gmail.com</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="invoice">Phone No: </label>
                                                                <p>04204545455</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="b-name">Country: </label>
                                                                <p>xyz</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="name">City: </label>
                                                                <p>xyz</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="name">State: </label>
                                                                <p>xyz</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="name">Zip: </label>
                                                                <p>xyz</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="name">Street: </label>
                                                                <p>xyz</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="name">Driving Licernse #: </label>
                                                                <p>1410900</p>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card ribbon-box border shadow-none mb-lg-0">
                                                <div class="card-body">
                                                    <div class="ribbon ribbon-primary round-shape">Booking Info</div>


                                                    <div class="ribbon-content mt-4 text-muted">
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <label for="name">Pickup Date: </label>
                                                                <p>xyz</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="email">Pickup Location: </label>
                                                                <p>xyz</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="invoice">Pickup Time: </label>
                                                                <p>xyz</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="b-name">Return Time: </label>
                                                                <p>xyz</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="name">Return Location: </label>
                                                                <p>xyz</p>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="card ribbon-box border shadow-none mb-lg-0">
                                                <div class="card-body">
                                                    <div class="ribbon ribbon-primary round-shape">Vehicle</div>
                                                    <div class="ribbon-content mt-4 text-muted">
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <label for="name">Vehicle Brand: </label>
                                                                <p>xyz</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="email">Vehicle Model: </label>
                                                                <p>xyz</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="invoice">Vehicle Type: </label>
                                                                <p>xyz</p>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card ribbon-box border shadow-none mb-lg-0">
                                                <div class="card-body">
                                                    <div class="ribbon ribbon-primary round-shape">Payment</div>
                                                    <div class="ribbon-content mt-4 text-muted">
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <label for="name">Payment Type: </label>
                                                                <p>Credit Card</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="email">Payment Package: </label>
                                                                <p>Weekly</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="invoice">Payment Total: </label>
                                                                <p>$2000</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="b-name">Payment Paid: </label>
                                                                <p>$500</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="name">Payment Remaining: </label>
                                                                <p>$1500</p>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <label for="name">Payment Invoice No: </label>
                                                                <p>#33445</p>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card ribbon-box border shadow-none mb-lg-0">
                                                <div class="card-body">
                                                    <div class="ribbon ribbon-primary round-shape">Inspection</div>
                                                    <div class="ribbon-content mt-4 text-muted">
                                                        <div class="row">
                                                            <figure class="col-md-3 img-figure-tag">
                                                                <a href="{{url('assets')}}/images/toyota-img1.png" data-size="1600x950">
                                                                    <div><img src="{{url('assets')}}/images/toyota-img1.png" alt="Image description" class="img-fluid img-hover">
                                                                    </div>
                                                                </a>
                                                            </figure>
                                                            <figure class="col-md-3 img-figure-tag">
                                                                <a href="{{url('assets')}}/images/toyota-img2.png" data-size="1600x950">
                                                                    <div><img src="{{url('assets')}}/images/toyota-img2.png" alt="Image description" class="img-fluid img-hover"></div>
                                                                </a>
                                                            </figure>
                                                            <figure class="col-md-3 img-figure-tag">
                                                                <a href="{{url('assets')}}/images/mitsubishi-img1.png" data-size="1600x950">
                                                                    <div><img src="{{url('assets')}}/images/mitsubishi-img1.png" alt="Image description" class="img-fluid img-hover"></div>
                                                                </a>

                                                            </figure>
                                                            <figure class="col-md-3 img-figure-tag">
                                                                <a href="{{url('assets')}}/images/hyundai-img1.png" data-size="1600x950">
                                                                    <div><img src="{{url('assets')}}/images/hyundai-img1.png" alt="Image description" class="img-fluid img-hover"></div>
                                                                </a>
                                                            </figure>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="d-flex justify-content-end">
                                            <a href="#"><button class="btn btn-primary">Confirm</button></a>
                                        </div>
                                    </div>
                                    <!-- summary tab end -->
                                </div>
                                <!-- end tab content -->
                            </form>
                        </div>
                        <!-- end card body -->
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
        </div>
    </div>
</div>

<!-- Dropzone min -->
<script href="{{url('assets')}}/libs/dropzone/dropzone-min.js"></script>
<script>
function showDriverName() {
    let catchSelectId = document.getElementById('driver');
    let driver = document.getElementById('driverBlock')
    if (catchSelectId.options[catchSelectId.selectedIndex].value == "with") {
        driver.style.display = 'inline-block';
    } else {
        driver.style.display = 'none';
    }
}
</script>
@include('admin.footer')
<!-- las la-angle-double-up -->
<!-- las la-angle-double-down -->
