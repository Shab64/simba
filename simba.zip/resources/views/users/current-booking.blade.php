@include('users.header')

    <link rel="stylesheet" href="{{url('assets/users')}}/css/vik.css">

    <!--    <link rel="stylesheet" href="{{url('assets/users')}}/css/frm-wiz/mStyle.css">-->
    <!--    <link rel="stylesheet" href="{{url('assets/users')}}/css/frm-wiz/js-steps.css">-->





    <section class="product-listing page-section-ptb">

        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body checkout-tab">
                            <input type="text" name="daterange" value="01/01/2018 - 01/15/2018" />
                        </div>
                        <!-- end card body -->
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>

        </div>



    </section>













@include('users.footer')
