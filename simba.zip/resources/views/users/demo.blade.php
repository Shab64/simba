<div clas="row">
               <div class="col-md-4">
                    <!-- menu logo -->
          <ul class="menu-logo">
              <li>
                  <a href="index.php"><img id="logo_dark_img" src="{{url('assets/users')}}/images/simba.png" alt="logo"> </a>
              </li>
          </ul>
               </div>
               <div class="col-md-8">
                   <!-- menu links -->
          <ul class="menu-links">
              <!-- active class -->
            <li class="active"><a href="index.php"> Home </a></li>
            <li class="active"><a href="our-fleet.php"> Our Fleet </a></li>
            <li class="active"><a href="contact-us.php"> Contact Us </a></li>
            <li class="active"><a href="index.php #feed"> Feedback </a></li>
            <li class="active"><a class="button red" href="login.php">Login</a></li>
        </ul>
               </div>

           </div>


           <header id="header" class="topbar-dark logo-center">
<div class="topbar">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <div class="topbar-left text-md-start text-center">
           <ul class="list-inline">
             <li> <i class="fa fa-envelope-o"> </i> admin@simbacarhire.com.au</li>
           </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="topbar-right text-md-end text-center">
           <ul class="list-inline">
             <li> <i class="fa fa-phone"></i>08 8312 4616</li>
             <li><a href="#"><i class="fa fa-facebook"></i></a></li>

           </ul>
        </div>
      </div>
    </div>
  </div>
</div>

<!--=================================
 mega menu -->

<div class="menu">
  <!-- menu start -->
   <nav id="menu" class="mega-menu">
    <!-- menu list items container -->
    <section class="menu-list-items">
     <div class="container">
      <div class="row">
       <div class="col-md-4 text-center position-relative">
       <ul class="menu-logo">
              <li>
                  <a href="index.php"><img id="logo_dark_img" src="{{url('assets/users')}}/images/simba.png" alt="logo"> </a>
              </li>
          </ul>


       </div>
       <div class="col-md-8">
       <ul class="menu-links">
              <!-- active class -->
            <li class="active"><a href="index.php"> Home </a></li>
            <li class="active"><a href="our-fleet.php"> Our Fleet </a></li>
            <li class="active"><a href="contact-us.php"> Contact Us </a></li>
            <li class="active"><a href="index.php #feed"> Feedback </a></li>
            <li class="active"><a class="button red" href="login.php">Login</a></li>
        </ul>
       </div>
      </div>
     </div>
    </section>
   </nav>
  <!-- menu end -->
 </div>
</header>


<div id="rev_slider_6_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="slider-7" style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">
<!-- START REVOLUTION SLIDER 5.2.6 fullwidth mode -->
  <div id="rev_slider_6_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.2.6">
<ul>  <!-- SLIDE  -->
    <li data-index="rs-11" data-transition="random-static,random,random-premium" data-slotamount="default,default,default,default" data-hideafterloop="0" data-hideslideonmobile="off"  data-randomtransition="on" data-easein="default,default,default,default" data-easeout="default,default,default,default" data-masterspeed="default,default,default,default"  data-thumb="revolution/assets/slider-8/100x50_mainbg2.jpg"  data-rotate="0,0,0,0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
    <!-- MAIN IMAGE -->
        <img src="{{url('assets/users')}}/revolution/assets/slider-8/mainbg2.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
    <!-- LAYERS -->

    <!-- LAYER NR. 1 -->
    <div class="tp-caption   tp-resizeme"
       id="slide-11-layer-6"
       data-x="['left','left','center','center']" data-hoffset="['0','15','0','0']"
       data-y="['top','top','top','top']" data-voffset="['110','131','69','79']"
            data-width="none"
      data-height="none"
      data-whitespace="nowrap"
      data-transform_idle="o:1;"

       data-transform_in="x:right;s:820;e:Power2.easeInOut;"
       data-transform_out="x:left;s:650;e:Power3.easeIn;"
      data-start="850"
      data-responsive_offset="on"

       data-end="8350"

      style="z-index: 5;"><img src="{{url('assets/users')}}/revolution/assets/slider-8/audi_PNG1764.png" alt="" data-ww="['653px','586.873417721519','586px','451px']" data-hh="['237px','213','213px','164px']" data-no-retina> </div>

    <!-- LAYER NR. 2 -->
    <div class="tp-caption   tp-resizeme"
       id="slide-11-layer-3"
       data-x="['left','left','center','center']" data-hoffset="['710','628','0','0']"
       data-y="['top','top','top','top']" data-voffset="['120','144','303','272']"
            data-fontsize="['65','45','45','45']"
      data-lineheight="['65','45','45','45']"
      data-width="none"
      data-height="none"
      data-whitespace="nowrap"
      data-transform_idle="o:1;"

       data-transform_in="y:-50px;opacity:0;s:1120;e:Power2.easeInOut;"
       data-transform_out="opacity:0;s:560;"
      data-start="1690"
      data-splitin="none"
      data-splitout="none"
      data-responsive_offset="on"

       data-end="8380"

      style="z-index: 6; white-space: nowrap; font-size: 65px; line-height: 65px; font-weight: 700; color: rgba(255, 255, 255, 1.00);font-family:Roboto;text-transform:uppercase;">find the right <br>car for you </div>

    <!-- LAYER NR. 3 -->
    <div class="tp-caption rev-btn "
       id="slide-11-layer-4"
       data-x="['left','left','center','center']" data-hoffset="['720','636','0','0']"
       data-y="['top','top','top','top']" data-voffset="['289','271','421','389']"
        data-fontsize="['17','17','14','13']"
      data-lineheight="['17','17','14','13']"
            data-width="none"
      data-height="none"
      data-whitespace="nowrap"
      data-transform_idle="o:1;"
        data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:0;e:Linear.easeNone;"
       data-style_hover="c:rgba(0,0,0,1);bg:rgba(255,255,255,1);"

       data-transform_in="y:50px;opacity:0;s:760;e:Power2.easeInOut;"
       data-transform_out="opacity:0;s:540;"
      data-start="2340"
      data-splitin="none"
      data-splitout="none"
      data-responsive_offset="on"
      data-responsive="off"
       data-end="8410"

      style="z-index: 7; white-space: nowrap; font-size: 17px; line-height: 17px; font-weight: 500; color: rgba(255,255,255,1);font-family:Roboto;text-transform:uppercase;background-color:rgba(0, 0, 0, 1.00);padding:12px 35px 12px 35px;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;"> <a href="#form">Search now</a>  </div>
  </li>
  <!-- SLIDE  -->
    <li data-index="rs-12" data-transition="random-static,random-premium,random" data-slotamount="default,default,default,default" data-hideafterloop="0" data-hideslideonmobile="off"  data-randomtransition="on" data-easein="default,default,default,default" data-easeout="default,default,default,default" data-masterspeed="default,default,default,default"  data-thumb="revolution/assets/slider-8/100x50_mainbg3.jpg"  data-rotate="0,0,0,0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
    <!-- MAIN IMAGE -->
        <img src="{{url('assets/users')}}/revolution/assets/slider-8/mainbg3.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
    <!-- LAYERS -->

    <!-- LAYER NR. 1 -->
    <div class="tp-caption   tp-resizeme"
       id="slide-12-layer-6"
       data-x="['left','left','left','left']" data-hoffset="['50','50','249','101']"
       data-y="['top','middle','middle','middle']" data-voffset="['20','0','-98','-93']"
            data-width="none"
      data-height="none"
      data-whitespace="nowrap"
      data-transform_idle="o:1;"

       data-transform_in="x:-50px;opacity:0;s:1200;e:Power2.easeInOut;"
       data-transform_out="opacity:0;s:800;"
      data-start="1330"
      data-responsive_offset="on"


      style="z-index: 5;"><img src="{{url('assets/users')}}/revolution/assets/slider-8/left-car.png" alt="" data-ww="['223px','197px','141px','141px']" data-hh="['403px','357px','255px','255px']" data-no-retina> </div>

    <!-- LAYER NR. 2 -->
    <div class="tp-caption   tp-resizeme"
       id="slide-12-layer-7"
       data-x="['left','left','left','left']" data-hoffset="['273','247','389','242']"
       data-y="['top','middle','middle','middle']" data-voffset="['21','1','-97','-91']"
            data-width="none"
      data-height="none"
      data-whitespace="nowrap"
      data-transform_idle="o:1;"

       data-transform_in="x:50px;opacity:0;s:1210;e:Power2.easeInOut;"
       data-transform_out="opacity:0;s:800;"
      data-start="1310"
      data-responsive_offset="on"


      style="z-index: 6;"><img src="{{url('assets/users')}}/revolution/assets/slider-8/right-car.png" alt="" data-ww="['250px','224px','157.76425855513307','157.76425855513307']" data-hh="['401px','360px','253','253']" data-no-retina> </div>

    <!-- LAYER NR. 3 -->
    <div class="tp-caption   tp-resizeme"
       id="slide-12-layer-3"
       data-x="['left','left','center','center']" data-hoffset="['709','600','0','0']"
       data-y="['top','top','top','top']" data-voffset="['121','130','297','310']"
            data-fontsize="['65','45','45','40']"
      data-lineheight="['65','50','50','40']"
      data-color="['rgba(255, 255, 255, 1.00)','rgba(255, 255, 255, 1.00)','rgba(10, 10, 10, 1.00)','rgba(10, 10, 10, 1.00)']"
      data-width="none"
      data-height="none"
      data-whitespace="nowrap"
      data-transform_idle="o:1;"

       data-transform_in="y:-50px;opacity:0;s:730;e:Power2.easeInOut;"
       data-transform_out="opacity:0;s:770;"
      data-start="1910"
      data-splitin="none"
      data-splitout="none"
      data-responsive_offset="on"


      style="z-index: 7; white-space: nowrap; font-size: 65px; line-height: 65px; font-weight: 700; color: rgba(255, 255, 255, 1.00);font-family:Roboto;text-transform:uppercase;">Exploring the<br>best car ? </div>

    <!-- LAYER NR. 4 -->
    <div class="tp-caption rev-btn "
       id="slide-12-layer-4"
       data-x="['left','left','center','center']" data-hoffset="['720','607','0','-1']"
       data-y="['top','top','top','top']" data-voffset="['290','266','420','412']"
       data-fontsize="['17','17','14','13']"
      data-lineheight="['17','17','14','13']"
      data-width="none"
      data-height="none"
      data-whitespace="nowrap"
      data-transform_idle="o:1;"
        data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:0;e:Linear.easeNone;"
        data-style_hover="c:rgba(0,0,0,1);bg:rgba(255,255,255,1);"

       data-transform_in="y:50px;opacity:0;s:940;e:Power2.easeInOut;"
       data-transform_out="opacity:0;s:820;"
      data-start="2350"
      data-splitin="none"
      data-splitout="none"
      data-responsive_offset="on"
      data-responsive="off"

      style="z-index: 8; white-space: nowrap; font-size: 17px; line-height: 17px; font-weight: 500; color: rgba(255,255,255,1);font-family:Roboto;text-transform:uppercase;background-color:rgba(0, 0, 0, 1.00);padding:12px 35px 12px 35px;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;"> <a href="our-fleet.php">Search now</a>   </div>
  </li>
</ul>
<div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div> </div>
</div>
